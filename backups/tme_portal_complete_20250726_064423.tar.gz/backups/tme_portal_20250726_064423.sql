--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-07-26 06:44:23 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS tme_portal;
--
-- TOC entry 3499 (class 1262 OID 16384)
-- Name: tme_portal; Type: DATABASE; Schema: -; Owner: tme_user
--

CREATE DATABASE tme_portal WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE tme_portal OWNER TO tme_user;

\connect tme_portal

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 225 (class 1255 OID 16490)
-- Name: clean_expired_sessions(); Type: FUNCTION; Schema: public; Owner: tme_user
--

CREATE FUNCTION public.clean_expired_sessions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM sessions WHERE expires_at < CURRENT_TIMESTAMP;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.clean_expired_sessions() OWNER TO tme_user;

--
-- TOC entry 224 (class 1255 OID 16488)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: tme_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO tme_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 16454)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    resource character varying(255),
    resource_id character varying(255),
    details jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO tme_user;

--
-- TOC entry 220 (class 1259 OID 16453)
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO tme_user;

--
-- TOC entry 3500 (class 0 OID 0)
-- Dependencies: 220
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- TOC entry 218 (class 1259 OID 16421)
-- Name: permissions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    resource character varying(100),
    action character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO tme_user;

--
-- TOC entry 217 (class 1259 OID 16420)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO tme_user;

--
-- TOC entry 3501 (class 0 OID 0)
-- Dependencies: 217
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 223 (class 1259 OID 16498)
-- Name: security_alert_acknowledgments; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.security_alert_acknowledgments (
    alert_id integer NOT NULL,
    acknowledged_by integer,
    acknowledged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_alert_acknowledgments OWNER TO tme_user;

--
-- TOC entry 216 (class 1259 OID 16406)
-- Name: sessions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id integer,
    expires_at timestamp without time zone NOT NULL,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO tme_user;

--
-- TOC entry 222 (class 1259 OID 16468)
-- Name: system_config; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.system_config (
    key character varying(255) NOT NULL,
    value jsonb,
    description text,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_config OWNER TO tme_user;

--
-- TOC entry 219 (class 1259 OID 16432)
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.user_permissions (
    user_id integer NOT NULL,
    permission_id integer NOT NULL,
    granted_by integer,
    granted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_permissions OWNER TO tme_user;

--
-- TOC entry 215 (class 1259 OID 16386)
-- Name: users; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_code character varying(10) NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    department character varying(100) NOT NULL,
    designation character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'employee'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    must_change_password boolean DEFAULT true,
    last_password_change timestamp without time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'manager'::character varying, 'employee'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'pending'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO tme_user;

--
-- TOC entry 214 (class 1259 OID 16385)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO tme_user;

--
-- TOC entry 3502 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3300 (class 2604 OID 16457)
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- TOC entry 3297 (class 2604 OID 16424)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 3288 (class 2604 OID 16389)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3491 (class 0 OID 16454)
-- Dependencies: 221
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.audit_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent, created_at) FROM stdin;
1	1	SYSTEM_SETUP	database	\N	{"action": "initial_database_setup", "employees_created": 37}	\N	\N	2025-07-22 16:44:56.878186
3	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	curl/8.6.0	2025-07-22 16:55:41.873283
4	\N	login_failed	auth	09UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:55:51.322084
5	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:55:55.060674
6	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:09.246511
7	\N	login_failed	auth	00	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:25.675683
8	\N	login_failed	auth	00	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:35.083783
9	1	login_success	auth	\N	{"remember_me": false}	::1	curl/8.6.0	2025-07-22 16:57:02.785263
10	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:58:25.563298
11	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 17:02:33.389167
12	1	change_password_success	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 17:05:35.115218
13	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:17:39.754298
14	1	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:27:14.682869
15	\N	login_failed	auth	00 UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:27:38.690555
16	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:27:46.962367
17	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:28:05.721559
18	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:28:08.192537
19	1	admin_reset_password_user	user	\N	{"action": "reset_password", "target_user_id": 26}	::1	\N	2025-07-23 05:24:14.205437
20	1	security_alert_acknowledged	security_alert	\N	{"alert_id": "17"}	::1	\N	2025-07-23 06:42:16.928386
21	1	security_alert_acknowledged	security_alert	\N	{"alert_id": "7"}	::1	\N	2025-07-23 06:42:19.873399
22	1	security_alert_acknowledged	security_alert	\N	{"alert_id": "3"}	::1	\N	2025-07-23 06:42:23.922664
23	1	admin_update_user	user	\N	{"employee_code": "70 DN", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 17}	::1	\N	2025-07-23 07:06:49.412846
24	1	admin_update_user	user	\N	{"employee_code": "70 DN", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 17}	::1	\N	2025-07-23 07:07:26.130603
25	1	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:07:35.511807
26	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:07:49.697555
27	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:08:14.063833
28	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:09:23.189381
29	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:09:39.769986
30	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:10:04.582337
31	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:25:57.48443
32	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:26:20.19381
33	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:27:12.450161
34	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:31:47.134087
35	\N	login_failed	auth	70 DN	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:31:58.266506
36	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:32:07.72543
37	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:32:24.893838
38	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:17.817028
39	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:36.305605
40	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:55.047817
41	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:36:29.66431
42	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:36:43.631709
43	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:40:19.637713
44	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:40:34.058837
46	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:53:06.272541
47	\N	login_failed	auth	damir@tme-services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:59:58.083101
48	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:00:33.284227
49	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:01.949675
50	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:27.863024
51	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:55.428303
52	\N	login_failed	auth	damir@tme-services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:13:23.844928
53	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:13:36.453265
54	17	admin_update_user	user	\N	{"employee_code": "09 UH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 1}	::1	\N	2025-07-23 08:18:34.797244
55	17	admin_update_user	user	\N	{"employee_code": "13 DH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 2}	::1	\N	2025-07-23 08:19:29.582625
56	17	admin_update_user	user	\N	{"employee_code": "14 HH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 3}	::1	\N	2025-07-23 08:19:40.654586
57	17	admin_update_user	user	\N	{"employee_code": "19 DS", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 4}	::1	\N	2025-07-23 08:19:54.762489
58	17	admin_update_user	user	\N	{"employee_code": "22 NF", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 5}	::1	\N	2025-07-23 08:20:40.997268
59	17	admin_update_user	user	\N	{"employee_code": "23 TA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 6}	::1	\N	2025-07-23 08:21:00.118816
60	17	admin_update_user	user	\N	{"employee_code": "33 MK", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 8}	::1	\N	2025-07-23 08:21:15.238698
61	17	admin_update_user	user	\N	{"employee_code": "38 TZ", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 9}	::1	\N	2025-07-23 08:21:29.350076
62	17	admin_update_user	user	\N	{"employee_code": "40 AS", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 10}	::1	\N	2025-07-23 08:21:40.074939
63	17	admin_update_user	user	\N	{"employee_code": "42 RJ", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 11}	::1	\N	2025-07-23 08:22:03.480487
64	17	admin_update_user	user	\N	{"employee_code": "58 YF", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 15}	::1	\N	2025-07-23 08:22:53.195161
65	17	admin_update_user	user	\N	{"employee_code": "50 PA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 13}	::1	\N	2025-07-23 08:23:27.416484
66	17	admin_update_user	user	\N	{"employee_code": "14 HH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 3}	::1	\N	2025-07-23 08:23:36.747484
67	17	admin_update_user	user	\N	{"employee_code": "50 PA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 13}	::1	\N	2025-07-23 08:23:50.805524
68	17	admin_update_user	user	\N	{"employee_code": "25 KM", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 7}	::1	\N	2025-07-23 08:24:04.162672
69	17	admin_update_user	user	\N	{"employee_code": "103 BD", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 37}	::1	\N	2025-07-23 08:24:40.962139
70	17	admin_update_user	user	\N	{"employee_code": "96 TR", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 32}	::1	\N	2025-07-23 08:24:56.754657
71	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:01.898359
72	3	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:17.402974
73	3	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:22.638855
74	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:31.899608
75	32	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:33:56.249154
76	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:34:20.316443
77	17	admin_update_user	user	\N	{"employee_code": "25 KM", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 7}	::1	\N	2025-07-23 08:35:59.353617
78	17	admin_update_user	user	\N	{"employee_code": "96 TR", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 32}	::1	\N	2025-07-23 08:36:48.882006
79	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:37:03.564137
80	1	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:37:16.411262
81	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:37:42.242384
82	32	pdf_generated	cost_overview	\N	{"authority": "Not specified", "client_name": "Georgia Boutioni", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 09:11:14.775506
83	32	pdf_generated	cost_overview	\N	{"filename": "250723 Aurelius Marcus IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 09:16:24.521163
84	32	pdf_generated	golden_visa	\N	{"filename": "250723 Aurelius Marcus offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Marcus Aurelius", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-23 09:17:55.540976
85	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Gutenberg Julius IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Julius Gutenberg", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 10:22:51.73728
86	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 11:49:15.933106
87	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Anton Praven IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Praven Anton", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 11:53:55.044781
88	17	pdf_generated	golden_visa	\N	{"filename": "250723 Ceasar Julius offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Julius Ceasar", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-23 12:03:06.170193
89	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:25:45.835094
90	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:26:31.52797
91	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:26:35.15005
92	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Hohmann Uwe IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Uwe Hohmann", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 14:29:36.484366
93	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 10:10:30.081998
94	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:48:41.265292
95	37	logout	auth	\N	\N	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:52:41.223626
96	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:52:55.670035
97	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:53:24.145189
98	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 12:48:44.305002
99	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 12:49:06.716139
100	32	pdf_previewed	cost_overview	\N	{"filename": "250724 Shumacher Michael IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Michael Shumacher", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-24 12:51:19.415527
101	32	pdf_previewed	cost_overview	\N	{"filename": "250724 Corse Michael IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Michael Corse", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-24 13:09:15.385598
102	32	pdf_previewed	company_services	\N	{"filename": "250724 TME Services Corse.pdf", "client_name": "Michael Corse", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-24 13:13:45.672487
\.


--
-- TOC entry 3488 (class 0 OID 16421)
-- Dependencies: 218
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.permissions (id, name, description, resource, action, created_at) FROM stdin;
1	cost_overview_read	View cost overview calculations	cost_overview	read	2025-07-22 16:44:56.8482
2	cost_overview_write	Create and edit cost overviews	cost_overview	write	2025-07-22 16:44:56.8482
3	cost_overview_export	Export cost overview PDFs	cost_overview	export	2025-07-22 16:44:56.8482
4	company_services_read	View company services	company_services	read	2025-07-22 16:44:56.8482
5	company_services_write	Create and edit company services	company_services	write	2025-07-22 16:44:56.8482
6	company_services_export	Export company services PDFs	company_services	export	2025-07-22 16:44:56.8482
7	golden_visa_read	View golden visa applications	golden_visa	read	2025-07-22 16:44:56.8482
8	golden_visa_write	Create and edit golden visa applications	golden_visa	write	2025-07-22 16:44:56.8482
9	golden_visa_export	Export golden visa PDFs	golden_visa	export	2025-07-22 16:44:56.8482
10	taxation_read	View taxation documents	taxation	read	2025-07-22 16:44:56.8482
11	taxation_write	Create and edit taxation documents	taxation	write	2025-07-22 16:44:56.8482
12	taxation_export	Export taxation PDFs	taxation	export	2025-07-22 16:44:56.8482
13	user_management	Manage user accounts	users	admin	2025-07-22 16:44:56.8482
14	system_admin	System administration access	system	admin	2025-07-22 16:44:56.8482
15	audit_logs	View audit logs	audit	read	2025-07-22 16:44:56.8482
\.


--
-- TOC entry 3493 (class 0 OID 16498)
-- Dependencies: 223
-- Data for Name: security_alert_acknowledgments; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.security_alert_acknowledgments (alert_id, acknowledged_by, acknowledged_at) FROM stdin;
17	1	2025-07-23 06:42:16.924252
7	1	2025-07-23 06:42:19.87023
3	1	2025-07-23 06:42:23.921227
\.


--
-- TOC entry 3486 (class 0 OID 16406)
-- Dependencies: 216
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.sessions (id, user_id, expires_at, ip_address, user_agent, created_at, last_activity) FROM stdin;
1a45411d-a096-4474-9d78-1ed8aa379408	37	2025-07-24 23:52:55.667	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:52:55.666736	2025-07-24 11:52:55.666736
c623cbef-0405-4dca-8099-c7a897b64f14	37	2025-07-24 23:53:24.143	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:53:24.142802	2025-07-24 11:53:24.142802
056c46a1-38be-42f6-b394-771598c6d972	32	2025-07-25 00:49:06.697	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 12:49:06.696259	2025-07-24 12:49:06.696259
\.


--
-- TOC entry 3492 (class 0 OID 16468)
-- Dependencies: 222
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.system_config (key, value, description, updated_by, updated_at) FROM stdin;
password_policy	{"min_length": 8, "require_numbers": true, "require_symbols": true, "require_lowercase": true, "require_uppercase": true}	Password complexity requirements	\N	2025-07-22 16:44:56.848907
session_timeout	28800	Session timeout in seconds (8 hours)	\N	2025-07-22 16:44:56.848907
max_login_attempts	5	Maximum failed login attempts before account lockout	\N	2025-07-22 16:44:56.848907
lockout_duration	1800	Account lockout duration in seconds (30 minutes)	\N	2025-07-22 16:44:56.848907
company_name	"TME Services"	Company name for branding	\N	2025-07-22 16:44:56.848907
admin_email	"uwe@TME-Services.com"	System administrator email	\N	2025-07-22 16:44:56.848907
\.


--
-- TOC entry 3489 (class 0 OID 16432)
-- Dependencies: 219
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.user_permissions (user_id, permission_id, granted_by, granted_at) FROM stdin;
1	1	1	2025-07-22 16:44:56.868565
1	2	1	2025-07-22 16:44:56.868565
1	3	1	2025-07-22 16:44:56.868565
1	4	1	2025-07-22 16:44:56.868565
1	5	1	2025-07-22 16:44:56.868565
1	6	1	2025-07-22 16:44:56.868565
1	7	1	2025-07-22 16:44:56.868565
1	8	1	2025-07-22 16:44:56.868565
1	9	1	2025-07-22 16:44:56.868565
1	10	1	2025-07-22 16:44:56.868565
1	11	1	2025-07-22 16:44:56.868565
1	12	1	2025-07-22 16:44:56.868565
1	13	1	2025-07-22 16:44:56.868565
1	14	1	2025-07-22 16:44:56.868565
1	15	1	2025-07-22 16:44:56.868565
2	1	1	2025-07-22 16:44:56.870649
2	2	1	2025-07-22 16:44:56.870649
2	3	1	2025-07-22 16:44:56.870649
2	4	1	2025-07-22 16:44:56.870649
2	5	1	2025-07-22 16:44:56.870649
2	6	1	2025-07-22 16:44:56.870649
2	7	1	2025-07-22 16:44:56.870649
2	8	1	2025-07-22 16:44:56.870649
2	9	1	2025-07-22 16:44:56.870649
2	10	1	2025-07-22 16:44:56.870649
2	11	1	2025-07-22 16:44:56.870649
2	12	1	2025-07-22 16:44:56.870649
3	1	1	2025-07-22 16:44:56.870649
3	2	1	2025-07-22 16:44:56.870649
3	3	1	2025-07-22 16:44:56.870649
3	4	1	2025-07-22 16:44:56.870649
3	5	1	2025-07-22 16:44:56.870649
3	6	1	2025-07-22 16:44:56.870649
3	7	1	2025-07-22 16:44:56.870649
3	8	1	2025-07-22 16:44:56.870649
3	9	1	2025-07-22 16:44:56.870649
3	10	1	2025-07-22 16:44:56.870649
3	11	1	2025-07-22 16:44:56.870649
3	12	1	2025-07-22 16:44:56.870649
4	1	1	2025-07-22 16:44:56.870649
4	2	1	2025-07-22 16:44:56.870649
4	3	1	2025-07-22 16:44:56.870649
4	4	1	2025-07-22 16:44:56.870649
4	5	1	2025-07-22 16:44:56.870649
4	6	1	2025-07-22 16:44:56.870649
4	7	1	2025-07-22 16:44:56.870649
4	8	1	2025-07-22 16:44:56.870649
4	9	1	2025-07-22 16:44:56.870649
4	10	1	2025-07-22 16:44:56.870649
4	11	1	2025-07-22 16:44:56.870649
4	12	1	2025-07-22 16:44:56.870649
5	1	1	2025-07-22 16:44:56.870649
5	2	1	2025-07-22 16:44:56.870649
5	3	1	2025-07-22 16:44:56.870649
5	4	1	2025-07-22 16:44:56.870649
5	5	1	2025-07-22 16:44:56.870649
5	6	1	2025-07-22 16:44:56.870649
5	7	1	2025-07-22 16:44:56.870649
5	8	1	2025-07-22 16:44:56.870649
5	9	1	2025-07-22 16:44:56.870649
5	10	1	2025-07-22 16:44:56.870649
5	11	1	2025-07-22 16:44:56.870649
5	12	1	2025-07-22 16:44:56.870649
8	1	1	2025-07-22 16:44:56.870649
8	2	1	2025-07-22 16:44:56.870649
8	3	1	2025-07-22 16:44:56.870649
8	4	1	2025-07-22 16:44:56.870649
8	5	1	2025-07-22 16:44:56.870649
8	6	1	2025-07-22 16:44:56.870649
8	7	1	2025-07-22 16:44:56.870649
8	8	1	2025-07-22 16:44:56.870649
8	9	1	2025-07-22 16:44:56.870649
8	10	1	2025-07-22 16:44:56.870649
8	11	1	2025-07-22 16:44:56.870649
8	12	1	2025-07-22 16:44:56.870649
9	1	1	2025-07-22 16:44:56.870649
9	2	1	2025-07-22 16:44:56.870649
9	3	1	2025-07-22 16:44:56.870649
9	4	1	2025-07-22 16:44:56.870649
9	5	1	2025-07-22 16:44:56.870649
9	6	1	2025-07-22 16:44:56.870649
9	7	1	2025-07-22 16:44:56.870649
9	8	1	2025-07-22 16:44:56.870649
9	9	1	2025-07-22 16:44:56.870649
9	10	1	2025-07-22 16:44:56.870649
9	11	1	2025-07-22 16:44:56.870649
9	12	1	2025-07-22 16:44:56.870649
14	1	1	2025-07-22 16:44:56.870649
14	2	1	2025-07-22 16:44:56.870649
14	3	1	2025-07-22 16:44:56.870649
14	4	1	2025-07-22 16:44:56.870649
14	5	1	2025-07-22 16:44:56.870649
14	6	1	2025-07-22 16:44:56.870649
14	7	1	2025-07-22 16:44:56.870649
14	8	1	2025-07-22 16:44:56.870649
14	9	1	2025-07-22 16:44:56.870649
14	10	1	2025-07-22 16:44:56.870649
14	11	1	2025-07-22 16:44:56.870649
14	12	1	2025-07-22 16:44:56.870649
17	1	1	2025-07-22 16:44:56.870649
17	2	1	2025-07-22 16:44:56.870649
17	3	1	2025-07-22 16:44:56.870649
17	4	1	2025-07-22 16:44:56.870649
17	5	1	2025-07-22 16:44:56.870649
17	6	1	2025-07-22 16:44:56.870649
17	7	1	2025-07-22 16:44:56.870649
17	8	1	2025-07-22 16:44:56.870649
17	9	1	2025-07-22 16:44:56.870649
17	10	1	2025-07-22 16:44:56.870649
17	11	1	2025-07-22 16:44:56.870649
17	12	1	2025-07-22 16:44:56.870649
27	1	1	2025-07-22 16:44:56.870649
27	2	1	2025-07-22 16:44:56.870649
27	3	1	2025-07-22 16:44:56.870649
27	4	1	2025-07-22 16:44:56.870649
27	5	1	2025-07-22 16:44:56.870649
27	6	1	2025-07-22 16:44:56.870649
27	7	1	2025-07-22 16:44:56.870649
27	8	1	2025-07-22 16:44:56.870649
27	9	1	2025-07-22 16:44:56.870649
27	10	1	2025-07-22 16:44:56.870649
27	11	1	2025-07-22 16:44:56.870649
27	12	1	2025-07-22 16:44:56.870649
32	1	1	2025-07-22 16:44:56.870649
32	2	1	2025-07-22 16:44:56.870649
32	3	1	2025-07-22 16:44:56.870649
32	4	1	2025-07-22 16:44:56.870649
32	5	1	2025-07-22 16:44:56.870649
32	6	1	2025-07-22 16:44:56.870649
32	7	1	2025-07-22 16:44:56.870649
32	8	1	2025-07-22 16:44:56.870649
32	9	1	2025-07-22 16:44:56.870649
32	10	1	2025-07-22 16:44:56.870649
32	11	1	2025-07-22 16:44:56.870649
32	12	1	2025-07-22 16:44:56.870649
6	1	1	2025-07-22 16:44:56.874003
6	4	1	2025-07-22 16:44:56.874003
6	7	1	2025-07-22 16:44:56.874003
6	10	1	2025-07-22 16:44:56.874003
7	1	1	2025-07-22 16:44:56.874003
7	4	1	2025-07-22 16:44:56.874003
7	7	1	2025-07-22 16:44:56.874003
7	10	1	2025-07-22 16:44:56.874003
10	1	1	2025-07-22 16:44:56.874003
10	4	1	2025-07-22 16:44:56.874003
10	7	1	2025-07-22 16:44:56.874003
10	10	1	2025-07-22 16:44:56.874003
11	1	1	2025-07-22 16:44:56.874003
11	4	1	2025-07-22 16:44:56.874003
11	7	1	2025-07-22 16:44:56.874003
11	10	1	2025-07-22 16:44:56.874003
12	1	1	2025-07-22 16:44:56.874003
12	4	1	2025-07-22 16:44:56.874003
12	7	1	2025-07-22 16:44:56.874003
12	10	1	2025-07-22 16:44:56.874003
13	1	1	2025-07-22 16:44:56.874003
13	4	1	2025-07-22 16:44:56.874003
13	7	1	2025-07-22 16:44:56.874003
13	10	1	2025-07-22 16:44:56.874003
15	1	1	2025-07-22 16:44:56.874003
15	4	1	2025-07-22 16:44:56.874003
15	7	1	2025-07-22 16:44:56.874003
15	10	1	2025-07-22 16:44:56.874003
16	1	1	2025-07-22 16:44:56.874003
16	4	1	2025-07-22 16:44:56.874003
16	7	1	2025-07-22 16:44:56.874003
16	10	1	2025-07-22 16:44:56.874003
18	1	1	2025-07-22 16:44:56.874003
18	4	1	2025-07-22 16:44:56.874003
18	7	1	2025-07-22 16:44:56.874003
18	10	1	2025-07-22 16:44:56.874003
19	1	1	2025-07-22 16:44:56.874003
19	4	1	2025-07-22 16:44:56.874003
19	7	1	2025-07-22 16:44:56.874003
19	10	1	2025-07-22 16:44:56.874003
20	1	1	2025-07-22 16:44:56.874003
20	4	1	2025-07-22 16:44:56.874003
20	7	1	2025-07-22 16:44:56.874003
20	10	1	2025-07-22 16:44:56.874003
21	1	1	2025-07-22 16:44:56.874003
21	4	1	2025-07-22 16:44:56.874003
21	7	1	2025-07-22 16:44:56.874003
21	10	1	2025-07-22 16:44:56.874003
22	1	1	2025-07-22 16:44:56.874003
22	4	1	2025-07-22 16:44:56.874003
22	7	1	2025-07-22 16:44:56.874003
22	10	1	2025-07-22 16:44:56.874003
23	1	1	2025-07-22 16:44:56.874003
23	4	1	2025-07-22 16:44:56.874003
23	7	1	2025-07-22 16:44:56.874003
23	10	1	2025-07-22 16:44:56.874003
24	1	1	2025-07-22 16:44:56.874003
24	4	1	2025-07-22 16:44:56.874003
24	7	1	2025-07-22 16:44:56.874003
24	10	1	2025-07-22 16:44:56.874003
25	1	1	2025-07-22 16:44:56.874003
25	4	1	2025-07-22 16:44:56.874003
25	7	1	2025-07-22 16:44:56.874003
25	10	1	2025-07-22 16:44:56.874003
26	1	1	2025-07-22 16:44:56.874003
26	4	1	2025-07-22 16:44:56.874003
26	7	1	2025-07-22 16:44:56.874003
26	10	1	2025-07-22 16:44:56.874003
28	1	1	2025-07-22 16:44:56.874003
28	4	1	2025-07-22 16:44:56.874003
28	7	1	2025-07-22 16:44:56.874003
28	10	1	2025-07-22 16:44:56.874003
29	1	1	2025-07-22 16:44:56.874003
29	4	1	2025-07-22 16:44:56.874003
29	7	1	2025-07-22 16:44:56.874003
29	10	1	2025-07-22 16:44:56.874003
30	1	1	2025-07-22 16:44:56.874003
30	4	1	2025-07-22 16:44:56.874003
30	7	1	2025-07-22 16:44:56.874003
30	10	1	2025-07-22 16:44:56.874003
31	1	1	2025-07-22 16:44:56.874003
31	4	1	2025-07-22 16:44:56.874003
31	7	1	2025-07-22 16:44:56.874003
31	10	1	2025-07-22 16:44:56.874003
33	1	1	2025-07-22 16:44:56.874003
33	4	1	2025-07-22 16:44:56.874003
33	7	1	2025-07-22 16:44:56.874003
33	10	1	2025-07-22 16:44:56.874003
34	1	1	2025-07-22 16:44:56.874003
34	4	1	2025-07-22 16:44:56.874003
34	7	1	2025-07-22 16:44:56.874003
34	10	1	2025-07-22 16:44:56.874003
35	1	1	2025-07-22 16:44:56.874003
35	4	1	2025-07-22 16:44:56.874003
35	7	1	2025-07-22 16:44:56.874003
35	10	1	2025-07-22 16:44:56.874003
36	1	1	2025-07-22 16:44:56.874003
36	4	1	2025-07-22 16:44:56.874003
36	7	1	2025-07-22 16:44:56.874003
36	10	1	2025-07-22 16:44:56.874003
37	1	1	2025-07-22 16:44:56.874003
37	4	1	2025-07-22 16:44:56.874003
37	7	1	2025-07-22 16:44:56.874003
37	10	1	2025-07-22 16:44:56.874003
38	1	1	2025-07-22 16:44:56.874003
38	4	1	2025-07-22 16:44:56.874003
38	7	1	2025-07-22 16:44:56.874003
38	10	1	2025-07-22 16:44:56.874003
39	1	1	2025-07-22 16:44:56.874003
39	4	1	2025-07-22 16:44:56.874003
39	7	1	2025-07-22 16:44:56.874003
39	10	1	2025-07-22 16:44:56.874003
40	1	1	2025-07-22 16:44:56.874003
40	4	1	2025-07-22 16:44:56.874003
40	7	1	2025-07-22 16:44:56.874003
40	10	1	2025-07-22 16:44:56.874003
41	1	1	2025-07-22 16:44:56.874003
41	4	1	2025-07-22 16:44:56.874003
41	7	1	2025-07-22 16:44:56.874003
41	10	1	2025-07-22 16:44:56.874003
42	1	1	2025-07-22 16:44:56.874003
42	4	1	2025-07-22 16:44:56.874003
42	7	1	2025-07-22 16:44:56.874003
42	10	1	2025-07-22 16:44:56.874003
\.


--
-- TOC entry 3485 (class 0 OID 16386)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.users (id, employee_code, email, full_name, department, designation, hashed_password, role, status, must_change_password, last_password_change, failed_login_attempts, locked_until, created_at, updated_at, last_login) FROM stdin;
12	48 AB	ashly@TME-Services.com	Ashly Biju	Accounting	Accountant	$2b$12$wBpskegBqVRWv8Poo7waZ.9FIYVLd5eA5tvpR8Sv8hbk/oMl4EsOS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
14	53 JT	jovel@TME-Services.com	Jovel Monton Tiro	Client Support	Administrative Supervisor	$2b$12$awVCySwpo7BhXUOdECa3m.Kgx5/MxYM/haqsNPbzF.3B5gyJ1VZ4K	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
16	65 WM	wilma@TME-Services.com	Wilma Menezes	Client Support	Client Support Coordinator	$2b$12$XiI0.oc75HEOFRlvnO0sseWqbZRFo/nhHi7vGEC/ZSUZSZdUyp8SW	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
18	75 WS	wafa@TME-Services.com	Wafa Sulthana Masood	Client Support	Client Support Coordinator	$2b$12$FfmPFckdcvqBfJaOozRQZet6zaW02C/7kwXktcLkR.xwk9.HgRlhy	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
19	76 RA	rowelyn@TME-Services.com	Rowelyn Allibang Jocson	Client Support	Marketing Specialist	$2b$12$Rr/9JO6JgZIQkZQ9hzlRy.ahDbvwmX46RVsuF.tgXr33daaTGi3Em	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
20	79 ST	surya@TME-Services.com	Surya Padmakumari Thulaseedharan	Client Support	Client Support Coordinator	$2b$12$ArlRYsHbopVGsY/rls9qdemoCdPQxgFJGiiTLgh9iRNRQNgrEpmMK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
21	80 RoJ	roja@TME-Services.com	Roja James	Tax & Compliance	Accountant	$2b$12$Vv84K9OZbhRs1l2a13cJEeUN8gxXlb.JpM9bHlSHpEidASSiPo8K2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
22	82 AC	alyssa@TME-Services.com	Alyssa Marie Jimenez Castillo	Client Support	Client Support Coordinator	$2b$12$MyAdnbDBMQUlUTJzjNwULut5k4pqTPnwRJgvltLmZfq5q76tideW2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
23	83 TM	tanya@TME-Services.com	Tanya Maria Miranda	Accounting	Accountant	$2b$12$yf3ssBi7.CdZ6rc2dXmeD.nUT1H4Ay7Jm5QlpcQP5rh.pk/Jx68Y.	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
24	86 MA	muhammed@TME-Services.com	Muhammed Anshad Chandveettil	Tax & Compliance	Accountant	$2b$12$/L6DbpuWBaR7.cgN6m8.qe/tVxQlnSJcDIBgeER3MwcX6emg1NQV.	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
25	87 VR	via@TME-Services.com	Via Andrea Rosales	Client Support	Receptionist	$2b$12$sKtOL3dmbUAe0AKp5aPOxuqsMtnySJBteCAZ6GyxnfZEI32T1M2uq	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
27	89 RR	renji@TME-Services.com	Renji Reghunadh	Client Support	Administration Manager	$2b$12$WSGVqnm807A8/wmBGNkVwu5jf/rPxW7.qQkZG/jNP6IPJjCtxIh/y	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
28	90 MD	alicia@TME-Services.com	Alicia Myles Elamparo Dela Cruz	Accounting	Assistant Accountant	$2b$12$K9Iuwvp7itX4VQmZT5WFpu9vb17.ZwUVT2J283itp.RDNLKBDlCt2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
29	91 PG	priya@TME-Services.com	Priya Ganapathy Kariappa	Client Support	Client Support Coordinator	$2b$12$W6WhAIiIfS/.wkWGnv41M.x3/uyG7wJuv2.geWskDGNQ94mjczAY6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
30	92 CM	chirath@TME-Services.com	Chirath Deshitha Mayakaduwa	Tax & Compliance	Accountant	$2b$12$GsPJ38WpwSDa/buXz85BX.0huZ8Dwp0FF.t/SD.SRW6..WIqjXBCK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
31	95 Sis	saquib@TME-Services.com	Saquib Siraj	Accounting	Accountant	$2b$12$6ubCs9./.kGnGh4aLj3j4u2gKJR7Q5Fgncm5s/GKek1aNRtPrkKri	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
33	98 NP	nidhi@TME-Services.com	Nidhi Pandey	Accounting	Accountant	$2b$12$9zoG6u7/IHOEVhzIycAfLuJF6SdSt8Cb.3uxcRytgLds9QtDyeleO	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
34	99 AtS	atheesha@TME-Services.com	Atheesha Shetty	Accounting	Accountant	$2b$12$czaGoPDdbfAPs2kbWG8naesXRv43OqetN8.ZVJ59ugGktp.wIxXm6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
35	100 MB	mehran@TME-Services.com	Mehran Masood Barde	Accounting	Accountant	$2b$12$3Ewzg5urFf06jb8XTUZAguLRDBOXxfI9XzYrJSlDadKSZHZ0b6QMK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
36	102 OO	onur@TME-Services.com	Onur Ozturk	Company Setup	Business Development Assistant	$2b$12$MGeVbEdtwYOjomVyUBqZZO5Rlw9ZnK5lUI10hOJhnqX8yyLcqirgG	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
26	88 AjA	aiswarya@TME-Services.com	Aiswarya Ajaykumar	Client Support	Client Support Coordinator	$2b$12$0/SMlKIWH5U4MLyKklxmsuwevACddCFocZUw86zeo04pK5DLrSScS	employee	active	t	2025-07-23 05:24:14.193621	0	\N	2025-07-22 16:44:56.86661	2025-07-23 05:24:14.193621	\N
7	25 KM	pro@TME-Services.com	Kumar & Ulesh	Client Support	Public Relation Officer (PRO)	$2b$12$qX9HtLpPC7kU6f4stkygUeKIjXvqpF0Fh..x94AaUz4nTKUIB2YqK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:35:59.346145	\N
2	13 DH	dijendra@TME-Services.com	Dijendra Hegde	Accounting	Chief Financial Officer (CFO)	$2b$12$JQydMDV6ibtE5AKPRYJgzua4hp5g25Nv2hUx49b.k0yFfcYpELtrG	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:19:29.572719	\N
13	50 PA	praveen@TME-Services.com	Praveen Anton	IT	System Administrator	$2b$12$KttUW.oKyYXTIg7DM/UAmuYivEWzq7qnMkhrCs838Z02EcYKz.Q/a	admin	active	f	2025-07-23 08:23:27.410984	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:23:50.799557	\N
4	19 DS	dakshath@TME-Services.com	Dakshath Shetty	Accounting	Accounting Manager	$2b$12$1N7Gsp0Hjp17O7jTmeSXUu3KWbBKcNMs8oxkqvWOAKGB0jH2eye3q	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:19:54.757968	\N
5	22 NF	natali@TME-Services.com	Natali Fernando	Client Support	Manager - Client Support 	$2b$12$I17vhtdIyqDTbHfVtCDRaezcycYY2gtzqL0tj0gVmiKotYmKT2jK2	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:20:40.99317	\N
6	23 TA	tabassum@TME-Services.com	Tabassum Arif	Accounting	Client Support Coordinator	$2b$12$OnHAmXzi3A2v8vyQk7oShu3FhHWZtAIcCSt2V7dXpQ7DqSVdjpLqa	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:00.115184	\N
8	33 MK	malavika@TME-Services.com	Malavika Kolera	Tax & Compliance	Director - Tax & Compliance	$2b$12$AHoq8AOHDgHpcBPABL638.gPD0JCRDABhhZwYRcFdx/Wcb65DD.Y.	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:15.233689	\N
9	38 TZ	tariq@TME-Services.com	Tariq Zarif	Accounting	Accounting Manager	$2b$12$ziEoWTTEBTDi9AcMXxI5weL.uJnk9c4waXNEmLD9CY9rGtr5SlXmK	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:29.343348	\N
10	40 AS	akash@TME-Services.com	Akash Shetty	Accounting	Accountant	$2b$12$BJYd2Kj3k20ICBRsibg46OIfV/iUoI/yy.wCEvuJSHE6jnvYRQtNC	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:40.072197	\N
11	42 RJ	reshma@TME-Services.com	Reshma Joseph	Tax & Compliance	Manager - VAT	$2b$12$gWpikDxiWiUCf4SqFWluvO2SHWXOzEyIg0cBMuGgR1uSTqn/oN2LS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:22:03.475263	\N
15	58 YF	yashika@TME-Services.com	Yashika Fernandes	Tax & Compliance	Manager - Compliance	$2b$12$grhFNo1XhOY.opXk7sMm2u0blsmy4TPfGE2S77cjjmkyy.wpC0yI6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:22:53.189314	\N
32	96 TR	tina@TME-Services.com	Tina Reimann	Company Setup	Assistant - Business Development	$2b$12$APzz85vN/CSHWbK5viSInOusl3z/STqm8fsFtA8nhd.TcjAVhSE/S	employee	active	f	2025-07-23 08:24:56.749222	0	\N	2025-07-22 16:44:56.86661	2025-07-24 12:49:06.660545	2025-07-24 12:49:06.660545
3	14 HH	hafees@TME-Services.com	Hafees Hameed	IT	Manager - IT Consulting	$2b$12$2wjz7BRq2GHVQes1j2b6WehNnSZUcCHXe.lNZgw0uTUuQLRaYdbbO	admin	active	f	2025-07-23 08:23:36.74016	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:28:17.393144	2025-07-23 08:28:17.393144
38	105 MM	milani@TME-Services.com	Milani Listin Morris	Client Support	Front Desk Support	$2b$12$xWNePVOt0f3K6Zn9dbPQnuvnPoBTsdfsKBGjUmbj/AZG5O8NZf9gW	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
39	106 CV	charltzon@TME-Services.com	Charltzon Varghese	Accounting	Accountant	$2b$12$fPkdhqX2QxWHBgkCTWhNZOxfTQ.298nMhC1f.U.fXERpf88eQdrp2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
40	108 MR	mohamed@TME-Services.com	Mohamed Rashid Basheer	Accounting	Accountant	$2b$12$At5piP59Q26auBZjUS6mqOZSR5HjXJvxTc7E3rpG/xWFcjkTXTt0C	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
41	109 PS	princyss@TME-Services.com	Princyss Sampaga	Client Support	Administration Officer	$2b$12$TjYj8oODSqgBfjJoNBR0OugFiZrovCQqdyV7eD/NzjtMOT7cCBgKS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
42	110 CD	carol@TME-Services.com	Carol Jenifa Dalmeida	Accounting	Accountant	$2b$12$Y88ngJPyof0nQ1zyIWxisO9XnYuQ/JcgLzCarZIPoHKcA0Ib10Gn2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
1	09 UH	uwe@TME-Services.com	Uwe Hohmann	Management	Managing Director	$2b$12$wqn4i6kHgR2gd1Wy.qXHGOh4KlKSKVYoP8Y0pbvVjrPl4WB0zk6xm	admin	active	f	2025-07-22 17:05:35.106219	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:37:16.405299	2025-07-23 08:37:16.405299
17	70 DN	damir@TME-Services.com	Damir Novalic	Marketing 	Manager - Digital Marketing	$2b$12$xDF1tMmOJncH6fFf/jJD3uF2NlcWEKtbR3AQCLPT7d5MtS4cfkmnW	admin	active	f	2025-07-23 07:06:49.398946	0	\N	2025-07-22 16:44:56.86661	2025-07-24 10:10:29.700012	2025-07-24 10:10:29.700012
37	103 BD	brayan@TME-Services.com	Brayan Dsouza	IT	Information Technology Consultant	$2b$12$S73PMwjnSzknWJHYQRvavOCsKDAfRPfBjFzINAgcGsxgICfNl/Bpu	employee	active	f	2025-07-23 08:24:40.956203	0	\N	2025-07-22 16:44:56.86661	2025-07-24 11:53:24.140436	2025-07-24 11:53:24.140436
\.


--
-- TOC entry 3503 (class 0 OID 0)
-- Dependencies: 220
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 102, true);


--
-- TOC entry 3504 (class 0 OID 0)
-- Dependencies: 217
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 15, true);


--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.users_id_seq', 42, true);


--
-- TOC entry 3326 (class 2606 OID 16462)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3320 (class 2606 OID 16431)
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- TOC entry 3322 (class 2606 OID 16429)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3332 (class 2606 OID 16503)
-- Name: security_alert_acknowledgments security_alert_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.security_alert_acknowledgments
    ADD CONSTRAINT security_alert_acknowledgments_pkey PRIMARY KEY (alert_id);


--
-- TOC entry 3318 (class 2606 OID 16414)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3330 (class 2606 OID 16475)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- TOC entry 3324 (class 2606 OID 16437)
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (user_id, permission_id);


--
-- TOC entry 3310 (class 2606 OID 16405)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3312 (class 2606 OID 16403)
-- Name: users users_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_code_key UNIQUE (employee_code);


--
-- TOC entry 3314 (class 2606 OID 16401)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3327 (class 1259 OID 16487)
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- TOC entry 3328 (class 1259 OID 16486)
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- TOC entry 3315 (class 1259 OID 16485)
-- Name: idx_sessions_expires_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_sessions_expires_at ON public.sessions USING btree (expires_at);


--
-- TOC entry 3316 (class 1259 OID 16484)
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- TOC entry 3306 (class 1259 OID 16482)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3307 (class 1259 OID 16481)
-- Name: idx_users_employee_code; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_employee_code ON public.users USING btree (employee_code);


--
-- TOC entry 3308 (class 1259 OID 16483)
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- TOC entry 3341 (class 2620 OID 16491)
-- Name: sessions clean_sessions_trigger; Type: TRIGGER; Schema: public; Owner: tme_user
--

CREATE TRIGGER clean_sessions_trigger AFTER INSERT ON public.sessions FOR EACH STATEMENT EXECUTE FUNCTION public.clean_expired_sessions();


--
-- TOC entry 3340 (class 2620 OID 16489)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: tme_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3337 (class 2606 OID 16463)
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3339 (class 2606 OID 16504)
-- Name: security_alert_acknowledgments security_alert_acknowledgments_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.security_alert_acknowledgments
    ADD CONSTRAINT security_alert_acknowledgments_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- TOC entry 3333 (class 2606 OID 16415)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3338 (class 2606 OID 16476)
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 3334 (class 2606 OID 16448)
-- Name: user_permissions user_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- TOC entry 3335 (class 2606 OID 16443)
-- Name: user_permissions user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3336 (class 2606 OID 16438)
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-07-26 06:44:24 UTC

--
-- PostgreSQL database dump complete
--

