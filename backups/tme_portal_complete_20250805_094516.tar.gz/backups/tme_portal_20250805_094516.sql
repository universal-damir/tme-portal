--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-08-05 09:45:16 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS tme_portal;
--
-- TOC entry 3541 (class 1262 OID 16384)
-- Name: tme_portal; Type: DATABASE; Schema: -; Owner: tme_user
--

CREATE DATABASE tme_portal WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE tme_portal OWNER TO tme_user;

\connect tme_portal

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 227 (class 1255 OID 16490)
-- Name: clean_expired_sessions(); Type: FUNCTION; Schema: public; Owner: tme_user
--

CREATE FUNCTION public.clean_expired_sessions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM sessions WHERE expires_at < CURRENT_TIMESTAMP;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.clean_expired_sessions() OWNER TO tme_user;

--
-- TOC entry 226 (class 1255 OID 16488)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: tme_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO tme_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 16510)
-- Name: applications; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    form_data jsonb NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying,
    submitted_by_id integer NOT NULL,
    reviewer_id integer,
    review_comments text,
    urgency character varying(10) DEFAULT 'standard'::character varying,
    submitted_at timestamp without time zone,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT applications_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending_review'::character varying, 'under_review'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT applications_type_check CHECK (((type)::text = ANY ((ARRAY['golden-visa'::character varying, 'cost-overview'::character varying, 'company-services'::character varying, 'taxation'::character varying, 'corporate-changes'::character varying])::text[]))),
    CONSTRAINT applications_urgency_check CHECK (((urgency)::text = ANY ((ARRAY['standard'::character varying, 'urgent'::character varying])::text[])))
);


ALTER TABLE public.applications OWNER TO tme_user;

--
-- TOC entry 221 (class 1259 OID 16454)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    resource character varying(255),
    resource_id character varying(255),
    details jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO tme_user;

--
-- TOC entry 220 (class 1259 OID 16453)
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO tme_user;

--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 220
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- TOC entry 225 (class 1259 OID 16535)
-- Name: notifications; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    application_id uuid,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT notifications_type_check CHECK (((type)::text = ANY ((ARRAY['review_requested'::character varying, 'review_completed'::character varying, 'application_approved'::character varying, 'application_rejected'::character varying])::text[])))
);


ALTER TABLE public.notifications OWNER TO tme_user;

--
-- TOC entry 218 (class 1259 OID 16421)
-- Name: permissions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    resource character varying(100),
    action character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO tme_user;

--
-- TOC entry 217 (class 1259 OID 16420)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO tme_user;

--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 217
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 223 (class 1259 OID 16498)
-- Name: security_alert_acknowledgments; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.security_alert_acknowledgments (
    alert_id integer NOT NULL,
    acknowledged_by integer,
    acknowledged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.security_alert_acknowledgments OWNER TO tme_user;

--
-- TOC entry 216 (class 1259 OID 16406)
-- Name: sessions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id integer,
    expires_at timestamp without time zone NOT NULL,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO tme_user;

--
-- TOC entry 222 (class 1259 OID 16468)
-- Name: system_config; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.system_config (
    key character varying(255) NOT NULL,
    value jsonb,
    description text,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_config OWNER TO tme_user;

--
-- TOC entry 219 (class 1259 OID 16432)
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.user_permissions (
    user_id integer NOT NULL,
    permission_id integer NOT NULL,
    granted_by integer,
    granted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_permissions OWNER TO tme_user;

--
-- TOC entry 215 (class 1259 OID 16386)
-- Name: users; Type: TABLE; Schema: public; Owner: tme_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_code character varying(10) NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    department character varying(100) NOT NULL,
    designation character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'employee'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    must_change_password boolean DEFAULT true,
    last_password_change timestamp without time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'manager'::character varying, 'employee'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'pending'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO tme_user;

--
-- TOC entry 214 (class 1259 OID 16385)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: tme_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO tme_user;

--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tme_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3308 (class 2604 OID 16457)
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- TOC entry 3305 (class 2604 OID 16424)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 3296 (class 2604 OID 16389)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3534 (class 0 OID 16510)
-- Dependencies: 224
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.applications (id, type, title, form_data, status, submitted_by_id, reviewer_id, review_comments, urgency, submitted_at, reviewed_at, created_at, updated_at) FROM stdin;
8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	golden-visa	Damir Novalic - Property Investment Golden Visa	{"date": "2025-08-01", "lastName": "Novalic", "visaType": "property-investment", "firstName": "Damir", "dependents": {"spouse": {"required": false, "governmentFee": 6730, "tmeServicesFee": 3490}, "children": {"count": 0, "governmentFee": 5500, "tmeServicesFee": 2930}}, "companyName": "", "companyType": "management-consultants", "requiresNOC": false, "clientEmails": ["damirnovalic@gmail.com"], "exchangeRate": 4, "governmentFee": 10000, "tmeServicesFee": 4820, "secondaryCurrency": "EUR", "_submitter_message": "check this", "primaryVisaRequired": true, "propertyAuthorityFees": {"emiratesIdFee": 1155, "dldApprovalFee": 4020, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}, "skilledEmployeeAuthorityFees": {"emiratesIdFee": 1155, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}}	approved	32	2	go t o go	standard	2025-08-01 12:02:26.396802	2025-08-01 12:02:49.519137	2025-07-29 07:17:09.052967	2025-08-01 12:02:49.519137
bd21530b-1be1-4a12-b717-1a72ce21896b	golden-visa	Damir Novalic - Property Investment Golden Visa	{"date": "2025-07-29", "lastName": "Novalic", "visaType": "property-investment", "firstName": "Damir", "dependents": {"spouse": {"required": false, "governmentFee": 6730, "tmeServicesFee": 3490}, "children": {"count": 0, "governmentFee": 5500, "tmeServicesFee": 2930}}, "companyName": "", "companyType": "management-consultants", "requiresNOC": false, "exchangeRate": 4, "governmentFee": 10000, "tmeServicesFee": 4820, "secondaryCurrency": "EUR", "primaryVisaRequired": true, "propertyAuthorityFees": {"emiratesIdFee": 1155, "dldApprovalFee": 4020, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}, "skilledEmployeeAuthorityFees": {"emiratesIdFee": 1155, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}}	pending_review	1	2	\N	standard	2025-07-29 06:56:19.031811	\N	2025-07-29 06:48:21.596828	2025-07-31 13:42:05.167933
1b227812-350b-43cb-a94c-7a9d1c105cd1	cost-overview	Damir Novalic - IFZA (International Free Zone Authority) Cost Overview	{"visaCosts": {"childVisa": false, "spouseVisa": false, "vipStamping": false, "visaDetails": [], "numberOfVisas": 0, "reducedVisaCost": 0, "childVisaDetails": [], "vipStampingVisas": 0, "visaStatusChange": 0, "numberOfChildVisas": 0, "spouseVisaInsurance": "No Insurance", "childVisaVipStamping": 0, "childVisaStatusChange": 0, "spouseVisaVipStamping": false, "enableVisaStatusChange": false, "spouseVisaStatusChange": false}, "detLicense": {"rentType": "business-center", "licenseType": "commercial", "tmeServicesFee": 0, "reductionAmount": 0, "officeRentAmount": 0, "thirdPartyApproval": false, "applyPriceReduction": false, "mofaPowerOfAttorney": false, "landlordDepositAmount": 0, "mofaOwnersDeclaration": false, "mofaCommercialRegister": false, "activitiesToBeConfirmed": false, "thirdPartyApprovalAmount": 0, "mofaActualMemorandumOrArticles": false, "mofaCertificateOfIncorporation": false}, "ifzaLicense": {"visaQuota": 0, "licenseYears": 1, "depositAmount": 0, "tmeServicesFee": 9000, "reductionAmount": 0, "officeRentAmount": 0, "crossBorderLicense": false, "rentOfficeRequired": false, "thirdPartyApproval": false, "unitLeaseAgreement": true, "applyPriceReduction": false, "depositWithLandlord": false, "mofaPowerOfAttorney": true, "mofaOwnersDeclaration": false, "mofaCommercialRegister": false, "thirdPartyApprovalAmount": 0, "mofaActualMemorandumOrArticles": false, "mofaCertificateOfIncorporation": false}, "activityCodes": [], "clientDetails": {"date": "2025-08-05", "lastName": "Novalic", "firstName": "Damir", "companyName": "", "clientEmails": ["damirnovalic@gmail.com"], "exchangeRate": 4, "addressToCompany": false, "companySetupType": "Individual Setup", "secondaryCurrency": "EUR"}, "_submitter_message": "aaaa 1", "additionalServices": {"digitalBank": 3000, "companyStamp": 600, "emiratesPost": 1500, "personalBank": 3000, "accountingFee": 6293, "citRegistration": 2921, "citReturnFiling": 5198, "traditionalBank": 7000, "vatRegistration": 3625, "accountingFrequency": "yearly"}, "authorityInformation": {"areaInUAE": "DDP (Dubai Digital Park) Building A2", "legalEntity": "FZCO - LLC Structure", "numberOfShares": 10000, "shareCapitalAED": 100000, "valuePerShareAED": 10, "responsibleAuthority": "IFZA (International Free Zone Authority)", "activitiesToBeConfirmed": true}}	rejected	17	2	nope more detials	standard	2025-08-05 09:28:44.577119	2025-08-05 09:30:32.81892	2025-07-31 09:47:21.045213	2025-08-05 09:30:32.81892
a879d7b7-3052-4144-b982-4abef7e7f19c	golden-visa	Damir Novalic - Property Investment Golden Visa	{"date": "2025-07-29", "lastName": "Novalic", "visaType": "property-investment", "firstName": "Damir", "dependents": {"spouse": {"required": false, "governmentFee": 6730, "tmeServicesFee": 3490}, "children": {"count": 0, "governmentFee": 5500, "tmeServicesFee": 2930}}, "companyName": "", "companyType": "management-consultants", "requiresNOC": false, "exchangeRate": 4, "governmentFee": 10000, "tmeServicesFee": 4820, "secondaryCurrency": "EUR", "primaryVisaRequired": true, "propertyAuthorityFees": {"emiratesIdFee": 1155, "dldApprovalFee": 4020, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}, "skilledEmployeeAuthorityFees": {"emiratesIdFee": 1155, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}}	pending_review	1	2	\N	standard	2025-07-29 06:40:52.998308	\N	2025-07-29 06:32:11.469282	2025-07-31 13:42:05.167933
3da5a2ba-7970-421d-878a-a27711cf4261	golden-visa	Unnamed Client - Property Investment Golden Visa	{"date": "2025-08-01", "lastName": "", "visaType": "property-investment", "firstName": "", "dependents": {"spouse": {"required": false, "governmentFee": 6730, "tmeServicesFee": 3490}, "children": {"count": 0, "governmentFee": 5500, "tmeServicesFee": 2930}}, "companyName": "", "companyType": "management-consultants", "requiresNOC": false, "clientEmails": [""], "exchangeRate": 4, "governmentFee": 10000, "tmeServicesFee": 4820, "secondaryCurrency": "EUR", "primaryVisaRequired": true, "propertyAuthorityFees": {"emiratesIdFee": 1155, "dldApprovalFee": 4020, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}, "skilledEmployeeAuthorityFees": {"emiratesIdFee": 1155, "thirdPartyCosts": 1460, "visaCancelation": false, "visaCancelationFee": 185, "immigrationResidencyFee": 3160, "mandatoryUaeMedicalTest": 700, "professionalPassportPicture": 25}}	draft	2	\N	\N	standard	\N	\N	2025-07-30 06:32:59.070191	2025-08-01 07:58:39.004787
\.


--
-- TOC entry 3531 (class 0 OID 16454)
-- Dependencies: 221
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.audit_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent, created_at) FROM stdin;
3	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	curl/8.6.0	2025-07-22 16:55:41.873283
4	\N	login_failed	auth	09UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:55:51.322084
5	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:55:55.060674
6	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:09.246511
7	\N	login_failed	auth	00	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:25.675683
8	\N	login_failed	auth	00	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-22 16:56:35.083783
15	\N	login_failed	auth	00 UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:27:38.690555
17	\N	login_failed	auth	00UH	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 04:28:05.721559
26	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:07:49.697555
29	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:09:39.769986
30	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:10:04.582337
31	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:25:57.48443
32	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:26:20.19381
33	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:27:12.450161
34	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:31:47.134087
35	\N	login_failed	auth	70 DN	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:31:58.266506
36	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:32:07.72543
37	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:32:24.893838
38	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:17.817028
39	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:36.305605
40	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:33:55.047817
41	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:36:29.66431
42	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:36:43.631709
43	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:40:19.637713
44	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:40:34.058837
46	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:53:06.272541
47	\N	login_failed	auth	damir@tme-services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 07:59:58.083101
48	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:00:33.284227
49	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:01.949675
50	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:27.863024
51	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:04:55.428303
52	\N	login_failed	auth	damir@tme-services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:13:23.844928
53	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:13:36.453265
54	17	admin_update_user	user	\N	{"employee_code": "09 UH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 1}	::1	\N	2025-07-23 08:18:34.797244
55	17	admin_update_user	user	\N	{"employee_code": "13 DH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 2}	::1	\N	2025-07-23 08:19:29.582625
56	17	admin_update_user	user	\N	{"employee_code": "14 HH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 3}	::1	\N	2025-07-23 08:19:40.654586
57	17	admin_update_user	user	\N	{"employee_code": "19 DS", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 4}	::1	\N	2025-07-23 08:19:54.762489
58	17	admin_update_user	user	\N	{"employee_code": "22 NF", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 5}	::1	\N	2025-07-23 08:20:40.997268
59	17	admin_update_user	user	\N	{"employee_code": "23 TA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 6}	::1	\N	2025-07-23 08:21:00.118816
60	17	admin_update_user	user	\N	{"employee_code": "33 MK", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 8}	::1	\N	2025-07-23 08:21:15.238698
61	17	admin_update_user	user	\N	{"employee_code": "38 TZ", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 9}	::1	\N	2025-07-23 08:21:29.350076
62	17	admin_update_user	user	\N	{"employee_code": "40 AS", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 10}	::1	\N	2025-07-23 08:21:40.074939
63	17	admin_update_user	user	\N	{"employee_code": "42 RJ", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 11}	::1	\N	2025-07-23 08:22:03.480487
64	17	admin_update_user	user	\N	{"employee_code": "58 YF", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 15}	::1	\N	2025-07-23 08:22:53.195161
65	17	admin_update_user	user	\N	{"employee_code": "50 PA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 13}	::1	\N	2025-07-23 08:23:27.416484
66	17	admin_update_user	user	\N	{"employee_code": "14 HH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 3}	::1	\N	2025-07-23 08:23:36.747484
67	17	admin_update_user	user	\N	{"employee_code": "50 PA", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 13}	::1	\N	2025-07-23 08:23:50.805524
68	17	admin_update_user	user	\N	{"employee_code": "25 KM", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 7}	::1	\N	2025-07-23 08:24:04.162672
69	17	admin_update_user	user	\N	{"employee_code": "103 BD", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 37}	::1	\N	2025-07-23 08:24:40.962139
70	17	admin_update_user	user	\N	{"employee_code": "96 TR", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 32}	::1	\N	2025-07-23 08:24:56.754657
71	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:01.898359
72	3	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:17.402974
73	3	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:22.638855
74	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:28:31.899608
75	32	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:33:56.249154
76	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:34:20.316443
77	17	admin_update_user	user	\N	{"employee_code": "25 KM", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 7}	::1	\N	2025-07-23 08:35:59.353617
78	17	admin_update_user	user	\N	{"employee_code": "96 TR", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 32}	::1	\N	2025-07-23 08:36:48.882006
79	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:37:03.564137
81	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 08:37:42.242384
82	32	pdf_generated	cost_overview	\N	{"authority": "Not specified", "client_name": "Georgia Boutioni", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 09:11:14.775506
83	32	pdf_generated	cost_overview	\N	{"filename": "250723 Aurelius Marcus IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 09:16:24.521163
84	32	pdf_generated	golden_visa	\N	{"filename": "250723 Aurelius Marcus offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Marcus Aurelius", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-23 09:17:55.540976
85	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Gutenberg Julius IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Julius Gutenberg", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 10:22:51.73728
86	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 11:49:15.933106
87	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Anton Praven IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Praven Anton", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 11:53:55.044781
88	17	pdf_generated	golden_visa	\N	{"filename": "250723 Ceasar Julius offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Julius Ceasar", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-23 12:03:06.170193
89	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:25:45.835094
90	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:26:31.52797
91	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-23 14:26:35.15005
92	32	pdf_previewed	cost_overview	\N	{"filename": "250723 Hohmann Uwe IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Uwe Hohmann", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-23 14:29:36.484366
93	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 10:10:30.081998
94	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:48:41.265292
95	37	logout	auth	\N	\N	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:52:41.223626
96	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:52:55.670035
97	37	login_success	auth	\N	{"remember_me": false}	::ffff:192.168.97.96	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-07-24 11:53:24.145189
98	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 12:48:44.305002
99	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-24 12:49:06.716139
100	32	pdf_previewed	cost_overview	\N	{"filename": "250724 Shumacher Michael IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Michael Shumacher", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-24 12:51:19.415527
101	32	pdf_previewed	cost_overview	\N	{"filename": "250724 Corse Michael IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Michael Corse", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-24 13:09:15.385598
102	32	pdf_previewed	company_services	\N	{"filename": "250724 TME Services Corse.pdf", "client_name": "Michael Corse", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-24 13:13:45.672487
103	\N	login_failed	auth	damir@TME-Services.com	{"reason": "invalid_credentials"}	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 06:46:26.914967
104	17	login_success	auth	\N	{"remember_me": false}	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 06:46:30.493705
105	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 07:44:30.451113
106	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 07:49:44.773042
107	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-26 07:50:03.464553
108	17	pdf_previewed	golden_visa	\N	{"filename": "250726 Aurelius Marcus offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Marcus Aurelius", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-26 09:06:07.42393
109	17	pdf_previewed	golden_visa	\N	{"filename": "250726 Aurelius Marcus offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Marcus Aurelius", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-26 09:06:45.177848
110	17	pdf_previewed	golden_visa	\N	{"filename": "250726 Ceasar Julius offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Julius Ceasar", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-26 09:10:27.360825
111	17	pdf_previewed	golden_visa	\N	{"filename": "250726 Halkidikis Arisotelis offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Arisotelis Halkidikis", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-26 09:13:44.945321
112	17	pdf_previewed	golden_visa	\N	{"filename": "250726 Halkidikis Arisotelis offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Arisotelis Halkidikis", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-26 09:14:11.258652
113	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 05:15:58.103528
114	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:04:03.738124
115	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:05:17.172569
116	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:07:21.516706
117	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:07:46.496331
118	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:12:08.829614
119	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:12:54.112799
120	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 06:16:37.56813
121	17	pdf_previewed	cost_overview	\N	{"filename": "250727 Aurelius Marcus IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-27 07:16:53.676641
122	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-27 08:34:45.999547
123	32	pdf_generated	cost_overview	\N	{"filename": "250727 Damir+Uwe IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir+Uwe", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-27 09:05:32.003335
124	32	pdf_previewed	golden_visa	\N	{"filename": "250727 Hohman Uwe offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Uwe Hohman", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-27 09:32:47.019239
125	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 05:42:16.5605
126	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Aurelius Marcus IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Marcus Aurelius", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 06:49:13.059163
127	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 06:55:09.682863
128	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 06:55:48.838246
129	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 06:57:07.161471
130	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 07:00:26.082773
131	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-28 07:08:43.550044
132	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 1 1 2 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-28 07:09:03.213139
133	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:24:20.858016
134	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:25:47.607317
135	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:28:51.60462
136	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:39:02.957999
137	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:40:20.664575
138	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 07:41:34.021093
139	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 08:03:46.318014
140	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 08:23:44.921127
141	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 08:47:01.177313
142	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:03:55.076007
143	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:04:26.39136
144	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:08:58.408636
145	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:13:06.466905
146	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:15:27.197002
147	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:21:31.060874
148	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:23:42.225442
149	17	pdf_previewed	cost_overview	\N	{"filename": "250728 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-28 09:26:49.231484
150	17	pdf_previewed	company_services	\N	{"filename": "250728 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-28 10:41:28.004796
151	17	pdf_generated	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 12:54:16.346314
152	17	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 12:54:55.043259
153	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 13:47:23.680041
154	\N	login_failed	auth	onur@TME-Services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 13:47:55.595433
155	\N	login_failed	auth	onur@TME-Services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-28 13:48:14.454779
157	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:05:31.355509
158	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:06:57.192922
159	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:14:57.071181
160	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:17:25.465873
161	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:17:33.421301
162	32	pdf_previewed	golden_visa	\N	{"filename": "250728 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-28 15:18:28.011409
163	32	login_success	auth	\N	{"remember_me": true}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 03:51:41.133752
165	32	pdf_previewed	golden_visa	\N	{"filename": "250729 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-29 04:39:25.848399
168	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 05:07:28.057855
169	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 05:11:18.33162
170	\N	login_failed	auth	uwe@TME-Services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 06:41:39.57641
171	\N	login_failed	auth	bryan@TME-Services.com	{"reason": "invalid_credentials"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 06:42:19.127999
172	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 06:42:31.107367
173	17	admin_update_user	user	\N	{"employee_code": "09 uh", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 2}	::1	\N	2025-07-29 06:43:10.476453
174	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 06:43:17.161264
175	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 06:43:28.762023
176	\N	review_system_error_update_application	review_system	\N	{"error": "invalid input syntax for type uuid: \\"undefined\\"", "stack": "error: invalid input syntax for type uuid: \\"undefined\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__122d8530._.js:333:32\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__122d8530._.js:269:16)\\n    at async PUT (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__56ab1239._.js:781:29)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T06:59:00.236Z"}	\N	\N	2025-07-29 06:59:00.253775
177	\N	review_system_error_update_application	review_system	\N	{"error": "invalid input syntax for type uuid: \\"undefined\\"", "stack": "error: invalid input syntax for type uuid: \\"undefined\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__122d8530._.js:333:32\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__122d8530._.js:269:16)\\n    at async PUT (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__56ab1239._.js:781:29)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T06:59:05.071Z"}	\N	\N	2025-07-29 06:59:05.085172
178	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 07:31:45.362552
179	2	admin_update_user	user	\N	{"employee_code": "09 UH", "updated_fields": ["employee_code", "email", "full_name", "department", "designation", "role", "status", "password", "must_change_password"], "updated_user_id": 2}	::1	\N	2025-07-29 07:41:20.755204
180	32	pdf_previewed	golden_visa	\N	{"filename": "250729 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-29 07:58:00.344126
181	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 08:42:40.16045
182	32	pdf_previewed	golden_visa	\N	{"filename": "250729 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-29 08:42:55.233602
215	32	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 11:11:43.794499
217	2	pdf_generated	cost_overview	\N	{"filename": "250730 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Company Traders LLC", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-30 11:47:43.958725
219	2	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 11:51:06.750219
183	\N	review_system_error_update_application	review_system	\N	{"error": "invalid input syntax for type uuid: \\"undefined\\"", "stack": "error: invalid input syntax for type uuid: \\"undefined\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:333:32\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async PUT (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__534a2ce6._.js:1374:29)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:27:15.746Z"}	\N	\N	2025-07-29 09:27:15.789773
184	\N	review_system_error_update_application	review_system	\N	{"error": "invalid input syntax for type uuid: \\"undefined\\"", "stack": "error: invalid input syntax for type uuid: \\"undefined\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:333:32\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async PUT (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__534a2ce6._.js:1374:29)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:27:19.656Z"}	\N	\N	2025-07-29 09:27:19.669169
185	\N	review_system_error_update_application	review_system	\N	{"error": "invalid input syntax for type uuid: \\"undefined\\"", "stack": "error: invalid input syntax for type uuid: \\"undefined\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:333:32\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async PUT (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__534a2ce6._.js:1374:29)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:27:29.786Z"}	\N	\N	2025-07-29 09:27:29.838811
186	32	pdf_previewed	golden_visa	\N	{"filename": "250729 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-29 09:29:01.063655
187	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 09:36:16.570711
188	\N	review_system_error_submit_for_review	review_system	\N	{"error": "could not determine data type of parameter $1", "stack": "error: could not determine data type of parameter $1\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:427:21\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1355:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:46:27.530Z"}	\N	\N	2025-07-29 09:46:27.536828
189	\N	review_system_error_submit_for_review	review_system	\N	{"error": "could not determine data type of parameter $1", "stack": "error: could not determine data type of parameter $1\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:427:21\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1355:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:46:37.639Z"}	\N	\N	2025-07-29 09:46:37.641749
190	\N	review_system_error_submit_for_review	review_system	\N	{"error": "could not determine data type of parameter $1", "stack": "error: could not determine data type of parameter $1\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:427:21\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1355:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:47:35.868Z"}	\N	\N	2025-07-29 09:47:35.871692
191	\N	review_system_error_submit_for_review	review_system	\N	{"error": "could not determine data type of parameter $1", "stack": "error: could not determine data type of parameter $1\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:427:21\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1355:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:48:13.059Z"}	\N	\N	2025-07-29 09:48:13.059086
216	2	pdf_generated	cost_overview	\N	{"filename": "250730 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "Not specified", "client_name": "TME Testing Company LLC", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-30 11:40:56.030842
218	2	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 11:48:29.541178
192	\N	review_system_error_submit_for_review	review_system	\N	{"error": "could not determine data type of parameter $1", "stack": "error: could not determine data type of parameter $1\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:427:21\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1355:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-29T09:55:23.979Z"}	\N	\N	2025-07-29 09:55:23.979411
193	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 11:54:16.212016
194	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-29 14:39:34.528872
195	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 04:29:15.463053
196	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 04:29:36.830638
197	\N	review_system_error_create_notification	review_system	\N	{"error": "column \\"metadata\\" of relation \\"notifications\\" does not exist", "stack": "error: column \\"metadata\\" of relation \\"notifications\\" does not exist\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:645:28\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:516:17\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1483:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-30T04:50:06.099Z"}	\N	\N	2025-07-30 04:50:06.11207
198	\N	review_system_error_create_notification	review_system	\N	{"error": "column \\"metadata\\" of relation \\"notifications\\" does not exist", "stack": "error: column \\"metadata\\" of relation \\"notifications\\" does not exist\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:645:28\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:516:17\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1483:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-30T04:50:46.783Z"}	\N	\N	2025-07-30 04:50:46.795161
199	32	pdf_previewed	company_services	\N	{"filename": "250730 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-30 05:36:03.888881
200	32	pdf_previewed	company_services	\N	{"filename": "250730 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-30 05:46:11.682328
201	32	pdf_generated	company_services	\N	{"filename": "250730 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-30 05:46:16.868254
202	32	pdf_generated	cost_overview	\N	{"filename": "250730 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Company FZCO", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-30 10:43:08.221042
203	32	pdf_generated	cost_overview	\N	{"filename": "250730 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Company LLC", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-30 10:45:06.61757
204	32	pdf_generated	cost_overview	\N	{"filename": "250730 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Company LLC", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-07-30 10:46:02.667252
205	32	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 10:47:25.36031
206	32	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 10:47:38.682541
207	32	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 10:47:42.888843
208	32	pdf_generated	company_services	\N	{"filename": "250730 TME Services Imaginary Company Novalic.pdf", "client_name": "Imaginary Company Traders LLC", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-30 10:48:43.326082
209	2	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:04:20.269034
210	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:04:35.014076
211	32	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:04:50.191607
212	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:05:00.502983
213	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:08:12.50801
214	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 11:08:16.690513
220	2	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 11:51:42.961556
221	2	pdf_generated	golden_visa	\N	{"filename": "250730 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-30 11:51:54.620141
222	2	pdf_generated	company_services	\N	{"filename": "250730 TME Services Imaginary Traders Novalic.pdf", "client_name": "Imaginary Traders LLC", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-30 11:53:13.168865
223	2	pdf_previewed	cost_overview	\N	{"filename": "250730 Imaginary Traders LLC DET CORP setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Traders LLC", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-30 11:58:07.143145
224	2	pdf_generated	cost_overview	\N	{"filename": "250730 Imaginary Traders LLC DET CORP setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Traders LLC", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-30 11:58:36.377876
225	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-30 12:07:44.415888
226	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-31 04:02:22.604688
227	17	pdf_generated	cost_overview	\N	{"filename": "250731 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Imaginary Company Traders LLC", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-31 05:24:07.217359
228	17	pdf_generated	cost_overview	\N	{"filename": "250731 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-31 05:26:30.444754
229	17	pdf_generated	cost_overview	\N	{"filename": "250731 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "Not specified", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-31 05:29:31.764783
230	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 06:59:06.532592
231	17	pdf_generated	cost_overview	\N	{"filename": "250731 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-31 06:59:32.26911
232	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 07:04:25.486329
233	17	pdf_generated	company_services	\N	{"filename": "250731 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-31 07:19:19.687302
234	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 07:22:59.783949
235	17	pdf_previewed	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 07:23:42.91099
236	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 07:24:01.780194
237	17	pdf_generated	company_services	\N	{"filename": "250731 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-31 07:24:56.186052
238	17	pdf_previewed	company_services	\N	{"filename": "250731 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-31 07:25:02.445993
239	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 09:22:10.598309
240	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 09:22:34.70389
241	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 09:23:30.49104
242	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:07:30.507498
243	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:18:23.952051
244	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:26:07.033632
245	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:34:02.405194
246	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:35:32.696679
247	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:39:12.357533
248	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:44:03.392116
249	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:47:28.237266
250	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:51:42.584207
251	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:52:32.108636
252	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:53:05.012629
253	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:53:53.670803
254	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:57:23.690833
255	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:57:35.057882
256	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:57:56.515872
257	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 11:59:19.105843
258	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-31 12:04:07.914532
259	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-31 12:04:09.770297
260	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-31 12:04:46.312845
261	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:04:58.941559
262	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:07:47.755394
263	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:10:21.25434
264	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:13:48.129428
265	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:15:17.06765
266	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:15:35.980139
267	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:20:31.188233
268	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:20:46.243083
269	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:31:00.698021
270	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 12:39:48.895177
271	17	pdf_generated	cost_overview	\N	{"filename": "250731 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-07-31 12:51:07.305006
272	17	pdf_generated	company_services	\N	{"filename": "250731 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-07-31 12:55:50.612555
273	\N	review_system_error_submit_for_review	review_system	\N	{"error": "new row for relation \\"applications\\" violates check constraint \\"applications_urgency_check\\"", "stack": "error: new row for relation \\"applications\\" violates check constraint \\"applications_urgency_check\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:444:17\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1504:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-31T13:36:36.740Z"}	\N	\N	2025-07-31 13:36:36.739621
302	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 12:11:37.41475
609	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:12:01.09149
274	\N	review_system_error_submit_for_review	review_system	\N	{"error": "new row for relation \\"applications\\" violates check constraint \\"applications_urgency_check\\"", "stack": "error: new row for relation \\"applications\\" violates check constraint \\"applications_urgency_check\\"\\n    at /Users/damir/tme portal v5.2/node_modules/pg-pool/index.js:45:11\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\n    at async /Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:444:17\\n    at async safeDbOperation (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__df2adfcb._.js:269:16)\\n    at async POST (/Users/damir/tme portal v5.2/.next/server/chunks/[root-of-the-server]__4fda37ae._.js:1504:25)\\n    at async AppRouteRouteModule.do (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:34112)\\n    at async AppRouteRouteModule.handle (/Users/damir/tme portal v5.2/node_modules/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js:26:41338)\\n    at async doRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1518:42)\\n    at async DevServer.renderToResponseWithComponentsImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1920:28)\\n    at async DevServer.renderPageComponent (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2408:24)\\n    at async DevServer.renderToResponseImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:2445:32)\\n    at async DevServer.pipeImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:1008:25)\\n    at async NextNodeServer.handleCatchallRenderRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/next-server.js:305:17)\\n    at async DevServer.handleRequestImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/base-server.js:900:17)\\n    at async /Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:371:20\\n    at async Span.traceAsyncFn (/Users/damir/tme portal v5.2/node_modules/next/dist/trace/trace.js:157:20)\\n    at async DevServer.handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/dev/next-dev-server.js:368:24)\\n    at async invokeRender (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:237:21)\\n    at async handleRequest (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:428:24)\\n    at async requestHandlerImpl (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/router-server.js:452:13)\\n    at async Server.requestListener (/Users/damir/tme portal v5.2/node_modules/next/dist/server/lib/start-server.js:158:13)", "timestamp": "2025-07-31T13:39:08.342Z"}	\N	\N	2025-07-31 13:39:08.341234
275	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-07-31 13:57:07.152452
276	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 14:23:51.273664
277	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 14:24:59.727682
278	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 14:25:24.163171
279	17	pdf_generated	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 14:25:44.830799
280	17	pdf_previewed	golden_visa	\N	{"filename": "250731 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-07-31 14:28:09.981805
281	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 07:20:05.702378
282	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 07:22:19.698871
283	17	pdf_generated	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 07:24:23.90082
284	17	pdf_previewed	company_services	\N	{"filename": "250801 TME Services Imaginary Company Novalic.pdf", "client_name": "Imaginary Company Traders LLC", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 09:59:36.684538
285	17	pdf_generated	company_services	\N	{"filename": "250801 TME Services Imaginary Company Novalic.pdf", "client_name": "Imaginary Company Traders LLC", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 09:59:41.383212
286	17	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-01 11:11:29.692803
287	17	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 11:13:34.459444
288	17	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 11:17:46.288888
289	17	pdf_generated	golden_visa	\N	{"filename": "250801 Damir+Hafees offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir+Hafees", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 11:31:32.540097
290	17	pdf_previewed	company_services	\N	{"filename": "250801 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 11:42:46.579586
291	17	pdf_previewed	company_services	\N	{"filename": "250801 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 11:43:32.521108
292	17	pdf_previewed	company_services	\N	{"filename": "250801 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 11:44:02.172801
293	17	pdf_previewed	company_services	\N	{"filename": "250801 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 11:44:18.298888
294	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 11:47:19.666331
295	17	pdf_generated	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 11:49:28.584018
296	17	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 11:54:58.850854
297	2	logout	auth	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 11:55:02.58652
298	32	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 11:55:14.482341
299	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-01 11:55:30.899413
300	32	pdf_generated	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 11:57:10.551826
301	32	pdf_generated	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 12:02:59.372969
303	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 12:42:44.209974
304	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 12:48:27.284714
305	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 12:56:19.465732
306	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 12:58:44.690384
307	32	pdf_previewed	cost_overview	\N	{"filename": "250801 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-01 13:05:50.400291
308	32	pdf_previewed	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 13:08:24.450903
309	32	pdf_previewed	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 13:14:56.968823
310	32	pdf_previewed	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 13:17:00.296388
311	32	pdf_previewed	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 13:30:18.456414
312	32	pdf_previewed	golden_visa	\N	{"filename": "250801 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-01 13:38:09.34334
313	2	pdf_generated	company_services	\N	{"filename": "250801 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-01 14:35:39.691541
314	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-02 04:00:23.641731
315	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:10:18.074842
316	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:13:13.679055
317	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:14:14.725306
318	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:15:47.524328
319	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:16:33.09318
320	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:16:43.826844
321	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:18:55.99173
322	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:20:12.090083
323	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:23:05.510681
324	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:38:49.11224
325	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:39:13.024925
326	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:45:43.440472
327	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:49:38.549327
328	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:52:55.82142
329	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:57:14.033268
330	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 04:59:45.148778
331	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:01:00.876758
332	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:02:44.569262
333	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 3 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:03:53.396109
334	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:07:11.121863
335	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:09:23.11736
336	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:16:42.779892
337	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:17:22.572984
338	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:17:52.157069
339	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:18:09.189778
340	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:19:42.456756
341	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:19:54.904399
342	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:23:50.482093
343	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:24:00.156912
344	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:24:33.935134
345	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:26:08.96379
346	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:27:45.836227
347	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:27:59.993651
348	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:30:04.297827
349	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:34:40.072416
350	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:34:49.391898
351	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:36:53.264721
352	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:37:15.680388
353	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:38:46.924034
354	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:39:03.527287
355	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:40:56.582998
356	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:49:50.333598
357	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:52:28.795188
358	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:52:34.036478
359	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 05:55:21.130966
360	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 0 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 06:04:00.943096
361	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 06:04:18.125349
362	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 06:30:51.663152
363	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 06:30:57.385224
364	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 06:36:56.079626
365	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 06:37:23.89748
366	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 06:42:28.418672
367	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 06:53:40.729358
368	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:06:56.776326
369	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:17:31.031347
370	17	pdf_previewed	golden_visa	\N	{"filename": "250802 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-02 07:18:31.346443
371	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:25:05.036431
372	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:28:55.344146
373	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:32:15.561523
374	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:37:22.110276
375	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:41:44.80811
376	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 2 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:43:15.270899
377	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:49:15.531365
378	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:49:50.932913
379	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:55:47.268431
380	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 0 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:56:21.01295
381	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 07:57:59.248053
382	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:08:18.177611
383	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:11:31.061286
384	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:15:34.007999
385	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:19:22.329846
386	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 3 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:22:10.936282
387	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:31:37.462574
388	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:31:54.806934
389	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 08:32:36.989494
390	17	pdf_previewed	golden_visa	\N	{"filename": "250802 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-02 11:04:10.037279
391	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 11:05:59.637966
392	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-02 13:17:38.244236
393	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 13:49:44.434501
394	17	pdf_previewed	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-02 14:08:32.510705
395	17	pdf_generated	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 14:29:43.541841
396	17	pdf_generated	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 14:39:57.202637
397	17	pdf_generated	cost_overview	\N	{"filename": "250802 Novalic Damir IFZA 1 0 0 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-02 14:41:05.878444
398	17	pdf_generated	company_services	\N	{"filename": "250802 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-02 14:47:32.441456
399	17	pdf_generated	company_services	\N	{"filename": "250802 TME Services Hohmann.pdf", "client_name": "Uwe Hohmann", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-02 14:48:19.756482
400	17	pdf_generated	company_services	\N	{"filename": "250802 TME Services Hohmann.pdf", "client_name": "Uwe Hohmann", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-02 14:48:38.663745
401	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-02 15:10:09.439048
402	2	pdf_generated	golden_visa	\N	{"filename": "250802 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-02 15:10:43.702642
403	2	pdf_generated	golden_visa	\N	{"filename": "250802 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-02 15:11:36.280687
404	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-03 04:53:57.209073
405	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 04:55:13.907307
406	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 04:58:28.958001
407	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 04:59:24.896686
408	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:00:05.063199
409	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:05:01.806106
410	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:09:17.705091
411	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:09:34.942751
412	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:10:09.189003
413	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:18:53.515433
414	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:19:34.137237
415	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:22:24.915487
416	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 0 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:23:09.216411
417	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:26:32.766759
418	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:26:47.408501
419	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:32:05.385288
420	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 05:38:17.405863
421	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:39:13.326496
422	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:45:54.123726
423	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:46:14.84432
424	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:50:06.301168
425	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:51:36.636139
426	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:53:00.66901
427	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:53:48.676195
428	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 05:59:08.75428
429	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 06:02:06.35058
430	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 06:02:57.724429
431	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 06:14:17.54896
432	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:23:49.40864
433	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:32:36.769464
434	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:43:26.394481
435	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:52:28.423533
436	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:54:54.526935
437	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 1 1 2 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:55:23.623587
438	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:58:58.455002
439	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 06:59:49.590255
440	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:08:23.624581
441	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:09:27.872135
442	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:18:06.36971
443	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:30:18.957582
444	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:31:45.53564
445	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:33:30.073285
446	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:33:49.727533
447	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:38:00.682967
448	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:39:51.326383
449	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:44:36.497635
450	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:55:46.531049
451	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 07:56:19.969772
452	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 3 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 07:58:15.982342
453	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:00:20.471839
454	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 08:09:49.607684
455	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 08:13:48.081757
456	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "TME Services", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 08:14:16.209011
457	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:23:13.47329
458	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:27:46.210447
459	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:30:10.418752
460	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:32:50.422835
461	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:32:59.295006
462	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:33:15.483716
463	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:34:28.458886
464	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:35:20.27671
465	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:35:28.49758
466	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:37:40.600835
467	17	pdf_generated	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:40:37.277368
468	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:40:40.557706
469	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:43:23.224266
470	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:44:21.837359
471	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:46:27.773737
472	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:51:41.297142
473	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 08:51:52.236551
474	17	pdf_previewed	golden_visa	\N	{"filename": "250803 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-03 08:55:20.752502
475	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 08:57:56.160297
476	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 09:05:36.180651
477	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 09:06:51.247485
478	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 09:08:47.762223
479	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 09:08:58.090083
480	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 10:48:23.49592
481	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 10:48:37.440896
482	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 10:49:23.22908
483	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 10:59:20.37602
484	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 11:06:03.462199
485	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 11:06:51.152883
486	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 11:14:27.546261
487	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 11:28:34.188502
488	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:09:12.026181
489	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-03 12:09:34.290193
490	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:11:39.040455
491	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:12:21.931008
492	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir IFZA 1 0 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:13:16.026845
493	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:19:18.399579
494	17	pdf_previewed	cost_overview	\N	{"filename": "250803 Novalic Damir DET CORP setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-03 12:31:19.190074
495	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-04 04:06:48.217007
496	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 0 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:07:13.505854
497	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:07:32.53473
498	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:07:50.347822
499	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:12:28.811087
500	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:13:31.912269
501	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:16:35.613703
502	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:16:51.431483
503	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:17:19.090358
504	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:24:25.462284
505	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 3 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:31:43.711155
506	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:36:08.931732
507	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-04 04:37:22.857731
508	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:38:23.1492
509	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:40:43.104544
510	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:41:27.440741
511	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:41:50.204016
512	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:43:09.247843
513	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:43:52.642725
514	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:44:28.545467
515	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:48:40.648793
516	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:49:38.60789
517	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:49:56.811642
518	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:55:09.016646
519	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:55:30.053761
520	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 04:58:45.538635
521	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:00:45.150879
522	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:01:43.192077
523	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:02:24.315083
524	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:05:57.977223
525	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:06:39.403672
526	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:09:15.33367
527	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:10:50.740438
528	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:12:46.110366
529	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:14:36.153061
530	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:17:25.028895
531	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:19:12.212045
532	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:21:22.023375
533	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:22:01.238789
534	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:23:31.55556
535	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:24:02.811946
536	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:28:43.234494
537	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:29:18.584054
538	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:29:36.701662
539	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:30:14.085458
540	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:33:44.248613
541	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:34:41.105339
542	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:36:20.397605
543	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:37:17.40249
544	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:39:31.399897
545	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:49:47.362782
546	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:50:28.779105
547	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:55:41.304662
548	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:55:59.193419
549	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:56:23.208227
550	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:57:55.592372
551	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:58:30.087748
552	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 05:59:02.474098
553	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:00:52.302548
554	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:01:30.88863
555	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:03:59.105013
556	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:05:05.065186
557	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:05:44.551571
558	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:06:23.405807
559	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:07:15.070118
560	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:13:08.368304
561	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:13:51.313804
562	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:17:36.022084
563	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:18:02.986294
564	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:19:25.639427
565	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:21:25.889615
566	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:23:07.57448
567	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:23:49.25227
568	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:30:53.461729
569	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:32:38.892853
570	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:33:08.49978
571	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:34:17.193952
572	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:34:36.751429
573	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:35:40.504875
574	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:36:00.092286
575	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:36:23.591331
576	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:36:40.304248
577	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:41:45.654604
578	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:41:58.946355
579	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:42:46.169076
580	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:45:24.197921
581	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:45:46.641283
582	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:46:08.849541
583	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir DET INDIV setup AED EUR.pdf", "authority": "DET (Dubai Department of Economy and Tourism)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:46:32.722284
584	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:47:06.231879
585	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 2 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:47:42.94158
586	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 0 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 06:48:38.503854
587	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 07:06:05.475444
588	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 07:17:20.135675
589	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 07:18:32.610414
590	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 1 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 07:26:49.50795
591	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 07:37:22.153298
592	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:27:26.928173
593	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:27:57.734861
594	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:32:36.15762
595	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:34:59.542063
596	17	pdf_previewed	cost_overview	\N	{"filename": "250804 Novalic Damir IFZA 1 2 1 0 0 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": false}	127.0.0.1	unknown	2025-08-04 08:35:29.309266
597	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:38:09.789735
598	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:40:32.284879
599	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:44:14.869035
600	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:50:01.76997
601	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:55:19.930563
602	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 08:56:49.754918
603	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:00:10.295532
604	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:00:43.027392
605	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:03:24.339037
606	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:07:04.732932
607	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:07:23.636008
608	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:07:31.340799
610	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:12:16.425576
611	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:12:26.947614
612	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:12:37.423501
613	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:12:49.597318
614	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:17:20.562533
615	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:17:29.777184
616	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:23:36.878148
617	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:23:40.968319
618	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:23:55.847237
619	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:24:06.472393
620	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:24:26.312623
621	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:30:51.033034
622	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:40:31.000033
623	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:40:44.26613
624	17	pdf_previewed	golden_visa	\N	{"filename": "250804 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-04 09:41:20.28733
625	17	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 05:21:32.86657
626	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:22:14.447469
627	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:24:21.252051
628	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:24:51.393783
629	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:26:19.771956
630	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:28:56.97114
631	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:31:51.631048
632	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:32:06.79898
633	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:38:23.967868
634	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:38:36.308595
635	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:39:33.907063
636	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:42:24.598531
637	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:46:31.030175
638	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:47:00.796861
639	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:48:11.291219
640	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:50:11.029548
641	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa deposit.pdf", "visa_type": "time-deposit", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:51:41.442989
642	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:53:15.691628
643	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:53:27.573071
644	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:56:08.862526
645	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:57:49.252252
646	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:58:04.103944
647	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 05:58:09.08338
648	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:00:23.739275
649	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:00:58.758278
650	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:08:29.774217
651	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:09:22.65668
652	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:12:38.413097
653	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:28:00.238995
654	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:41:00.441281
655	17	pdf_previewed	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa skilled.pdf", "visa_type": "skilled-employee", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 06:42:15.568326
656	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:02:48.53257
657	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:06:43.81499
658	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:36:37.061677
659	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:40:17.899278
660	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:40:28.188461
661	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "tme-fzco", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:42:05.533312
662	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:44:12.22113
663	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:45:37.537667
664	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:54:10.924143
665	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:54:25.495067
666	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 07:56:51.701902
667	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 08:02:21.70541
668	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 08:03:46.404477
669	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 08:05:40.062358
670	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 08:06:53.566543
671	17	pdf_previewed	company_services	\N	{"filename": "250805 TME Services Novalic.pdf", "client_name": "Damir Novalic", "company_type": "management-consultants", "document_type": "Company Services"}	127.0.0.1	unknown	2025-08-05 08:09:23.515
672	17	pdf_generated	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 08:10:35.984699
673	17	pdf_generated	golden_visa	\N	{"filename": "250805 Novalic Damir offer golden visa property.pdf", "visa_type": "property-investment", "client_name": "Damir Novalic", "document_type": "Golden Visa"}	127.0.0.1	unknown	2025-08-05 08:10:43.337314
674	17	pdf_previewed	cost_overview	\N	{"filename": "250805 Novalic Damir IFZA 1 2 2 1 1 setup AED EUR.pdf", "authority": "IFZA (International Free Zone Authority)", "client_name": "Damir Novalic", "document_type": "Cost Overview", "has_family_visa": true}	127.0.0.1	unknown	2025-08-05 08:15:56.562805
675	2	login_success	auth	\N	{"remember_me": false}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 08:24:50.481633
676	17	login_success	auth	\N	{"remember_me": false}	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 09:42:59.368722
\.


--
-- TOC entry 3535 (class 0 OID 16535)
-- Dependencies: 225
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.notifications (id, user_id, type, title, message, application_id, is_read, created_at, metadata) FROM stdin;
2e365a86-aeaa-4769-bcd7-d388f478d5a5	2	review_requested	New Application for Review	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:51:38.247285	{}
50a90a72-22c1-4a33-b08e-11ccbfd5bc04	32	application_rejected	Application Rejected	Your application "Damir Novalic - Property Investment Golden Visa" has been rejectd. Comments: do more asdasd	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:52:24.832134	{}
24f7e083-4489-46a4-bd24-3b7d709c7c30	2	review_requested	New Application for Review	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:53:03.686704	{}
280b965d-77a3-4c8f-b9b0-0433229a4d3d	2	review_requested	250805 Client offer golden visa undefined	jjjjh	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:36:50.80767	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
e8dd026b-251c-418b-a072-b8f2a19c9a1e	32	application_approved	Application Approved	Your application "Unnamed Client - Property Investment Golden Visa" has been approved. Comments: a	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:53:24.411418	{}
e44a7612-af97-4e3a-90fe-1c5f4bd2a067	2	review_requested	New Application for Review	good	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:55:35.178149	{}
3588ee79-d6b2-4a72-bfdc-bce58da775ad	32	application_rejected	Application Rejected	Your application "Damir Novalic - Skilled Employee Golden Visa" has been rejectd. Comments: dadsaddssdasd	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 12:55:56.356639	{}
41a4d83d-91a5-4f42-84df-bdcc36971711	2	review_requested	New Application for Review	ast 1	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:00:16.912964	{}
cc60175d-540f-43da-bd52-e7d15148bde6	32	application_approved	Application Approved	Your application "Damir Novalic - Property Investment Golden Visa" has been approved. Comments: no needs more work the price is not correct.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:00:53.155528	{}
279ed323-b6bc-4981-942e-59ce3856d67b	2	review_requested	New Application for Review	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:01:34.266269	{}
5692e2ac-d705-4638-b45e-bd888274ba38	32	application_rejected	Application Rejected	Your application "Damir Novalic - Property Investment Golden Visa" has been rejectd. Comments: no more edits	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:01:57.132578	{}
7cb7108c-8d82-46e3-a015-0ddfd94377ab	2	review_requested	250729 Novalic Damir offer golden visa property	dadasd	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 14:40:44.661774	{}
8501f24d-683e-489b-8c24-92b1bb273213	32	application_rejected	Application Rejected	Your application "Damir Novalic - Property Investment Golden Visa" has been rejectd. Comments: sdsadadssasd	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 14:41:12.15624	{}
59c10729-a427-47a1-b24f-b6f85266fe56	2	review_requested	250729 Novalic Damir offer golden visa property	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 14:41:32.399369	{}
0098ce41-3d92-4647-ab1b-d6a98cf87281	2	review_requested	New Application for Review	testing new system. chek it out.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:37:31.859441	{}
80d198c4-010c-4340-8747-ff33c3bee097	2	review_requested	Damir Novalic - Property Investment Golden Visa	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 13:40:53.685448	{}
0e08f0e2-5087-4edf-b900-9a1d4b22e916	2	review_requested	250729 Novalic Damir offer golden visa property	adsaadasadssdads	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 14:38:35.551068	{}
9ebe4b81-3798-4d74-afc6-e9e9d4511e27	2	review_requested	250729 Novalic Damir offer golden visa property	change this	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-29 14:38:57.593577	{}
dbeaa4f7-4272-4fc9-a954-4a55e84c3d0b	2	review_requested	250730 Novalic Damir offer golden visa property	this is a new test review	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 04:36:52.647104	{}
dc698103-51cd-4414-a3c5-493cdf043d5b	32	application_rejected	Application Rejected	Your application "Damir Novalic - Property Investment Golden Visa" has been rejectd. Comments: needs more work	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 04:38:04.458603	{}
214921d2-d496-4d46-8c5f-c40537789f3a	2	review_requested	250730 Novalic Damir offer golden visa property	hey check this out	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 04:57:25.292044	{}
952467ba-0ff0-452b-abe4-1d2633d1b183	32	application_rejected	250730 Novalic Damir offer golden visa property Rejected	not good, check again	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 04:57:58.446368	{}
16cee1e2-4ece-4211-bc66-42bc775516c1	2	review_requested	250730 Novalic Damir offer golden visa deposit	is this good. check it	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 05:01:24.821728	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
8b8f9091-fd18-42f7-baee-e11635de0b7d	32	application_approved	250730 Novalic Damir offer golden visa deposit Approved	looks good to me	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 05:01:55.129385	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
af2db15a-b8ef-4bfd-8e9f-389b307ae54b	2	review_requested	250730 Novalic Damir offer golden visa property	chack this and save it in the folder x/testfolder/etc	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 05:13:42.048829	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
6dfb6d6e-0368-4a9e-80d5-34cf4a0033d5	32	application_approved	250730 Novalic Damir offer golden visa property Approved	this look good please send it to the client	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 05:14:40.370447	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
ad6e5f23-3aea-4f83-8751-3e42262535ec	2	review_requested	250730 Novalic Damir offer golden visa property	check this i have prepared offer for the client xyz llc. save it here	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:01:42.279221	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
479b6bf6-1d3a-42b1-a190-02eb6c0b17d9	32	application_rejected	250730 Novalic Damir offer golden visa property Rejected	this is not good change the price to be 25 instead of 125 for pp	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:02:46.593555	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
ecbb3835-4af8-4be5-8e97-043eb43699f0	2	review_requested	250730 Novalic Damir offer golden visa property	better?	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:03:19.327903	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
e71c4b16-0a6a-4d6c-a9af-550e095451a0	32	application_approved	250730 Novalic Damir offer golden visa property Approved	yes	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:03:32.821922	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
96359c1e-b9aa-44b3-8c33-34a27c886626	2	review_requested	250730 Novalic Damir offer golden visa property	I preapre dth offer. check it out	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:09:44.750297	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
ac7c8eb2-ee50-455e-b093-00282be8681a	32	application_rejected	250730 Novalic Damir offer golden visa property Rejected	this is not good change the amount there	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:10:19.574972	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
2a6c2fb3-cfe4-4f89-97f9-03724433f72a	2	review_requested	250730 Novalic Damir offer golden visa property	changed is	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:10:54.461197	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
0cb7a59e-71bf-4c22-80d1-5f507ec1986b	32	application_approved	250730 Novalic Damir offer golden visa property Approved	this is god to go save it her /Volumes/Data/Trust ME/Sales dept/Clients/15732 TME Social Media Marketing Co. LLC	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:11:28.965159	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
774dc09b-906a-40b4-b62b-519a76701a00	2	review_requested	250730 Novalic Damir offer golden visa property	test this now	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 11:19:56.463501	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
e565b5b7-0157-4b7c-81f4-d5ba58823de6	2	review_requested	250730 Client offer golden visa deposit	check and let me knwo	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 12:08:10.798648	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
34dc6a6c-1bf0-4fbc-871f-5aee7358f210	32	application_rejected	250730 Client offer golden visa deposit Rejected	change the ptrice nowt good	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 12:08:43.14244	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
1644502e-9b7b-430c-9f80-99e53afa9165	2	review_requested	250805 Client offer golden visa undefined	test cost overview	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:29:40.973446	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
aebc1fd4-ae75-485b-8111-2e26e261fa58	2	review_requested	250730 Client offer golden visa deposit	A new application has been submitted for your review.	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 12:09:23.151447	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
585b8812-d195-4b40-aa3c-16d036b64a3d	2	review_requested	250805 Novalic Damir offer golden visa property	test	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:10:28.180767	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
83ed9c96-fb23-45d8-bed9-11b182780b1f	32	application_approved	250730 Client offer golden visa deposit Approved	good to go save it her /Volumes/Data/Trust ME/Sales dept/Clients/15732 TME Social Media Marketing Co. LLC	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-07-30 12:09:37.197717	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
4879a953-5a94-4862-b86d-e52024b9b762	2	review_requested	250805 Client offer golden visa undefined	test 1	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:39:35.194467	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
a9a27130-d88e-4934-b7b6-751e55c143ca	2	review_requested	250731 Novalic Damir offer golden visa property	hey urgent, please review	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 13:56:32.366028	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
e59ec8c2-00f7-4af2-8bdf-e5730c994dcf	2	review_requested	250731 Novalic Damir offer golden visa property	hey	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 13:55:59.53953	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
60a69105-676c-4be2-b6eb-261234232a9d	2	review_requested	250731 Novalic Damir offer golden visa property	test	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 13:58:07.680212	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
35876bec-9914-4f43-b1f9-9a2496fa8f61	2	review_requested	250805 Client offer golden visa undefined	aaaa 1	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:42:31.93611	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
9f1b8833-114e-4f29-9236-61f5dbce723d	2	review_requested	250731 Novalic Damir offer golden visa property	hey check	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:08:12.840776	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
910eea1b-a9e2-4a09-8867-e390176bdf8a	2	review_requested	250805 Client offer golden visa undefined	aaaaassssss	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:44:31.911424	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
2392b49e-a680-455d-9c5e-c96262489ec5	2	review_requested	250731 Novalic Damir offer golden visa property	hey check	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:08:56.358589	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
a91c1fc4-f7a1-49d5-ae26-9ff777b89b6b	17	application_approved	250731 Novalic Damir offer golden visa property Approved	good to go	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:11:15.681523	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
d82d01c2-a044-4716-a259-7eebdc153b09	2	review_requested	250731 Novalic Damir offer golden visa property	hecy chek thi s for me	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:15:48.332563	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
b6a934e9-3c80-4f7d-bcfb-59b4b7eedc86	17	application_approved	250731 Novalic Damir offer golden visa property Approved	good	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:16:08.051614	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
2bc3d521-be76-4828-b74c-e0ea06ef994f	2	review_requested	250805 Client offer golden visa undefined	aaaddd	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:52:49.433575	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
c3208772-6bdd-4cf2-a221-4ac36abb4a1e	2	review_requested	250731 Novalic Damir offer golden visa property	test	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:23:28.932548	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
5b433638-9f16-4a41-a888-b82b0dfd047f	17	application_approved	250731 Novalic Damir offer golden visa property Approved	good	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:23:40.240476	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
0a48200f-43a6-4772-a6f4-78cc3afdda5c	2	review_requested	250805 Novalic Damir offer IFZA (International Free Zone Authority)	aaaaaa	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:57:58.538657	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
8123a7e7-af71-4582-9f74-3d4780cd63b3	2	review_requested	250731 Novalic Damir offer golden visa property	hey check this for testing	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:29:57.224716	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
2c41ebce-e999-473e-8701-6977ace51870	2	review_requested	250731 Novalic Damir offer golden visa property	tests	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-07-31 14:36:10.361495	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
172f926e-9a7f-4129-b031-05935d694067	2	review_requested	250805 Novalic Damir offer IFZA (International Free Zone Authority)	test work ?	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 09:19:20.604081	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
fde058a4-f2a2-494e-b6ee-cce2b344f952	2	review_requested	250801 Client offer golden visa property	Portal Test	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-01 07:21:21.234983	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
cc592755-8c46-4d32-9eba-1bebb60f3d89	2	review_requested	250801 Novalic Damir offer golden visa property	test	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-01 11:46:41.986909	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
a83c2bdb-a5ca-46e8-a860-2b7c788fda72	17	application_rejected	250805 Novalic Damir offer IFZA (International Free Zone Authority) Rejected	maybe cheeck it?	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 09:20:22.099681	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
ef1ab05e-d183-4fb2-928d-f5069e333f8e	17	application_approved	250801 Novalic Damir offer golden visa property Approved	yes perfect	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-01 11:49:13.761376	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
18c697e5-efc7-4173-820c-1226861c4e60	2	review_requested	250801 Novalic Damir offer golden visa property	check this	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-08-01 12:02:26.396802	{"submitter_name": "Tina Reimann", "submitter_employee_code": "96 TR"}
c9793bc1-31b7-417d-9e64-a2a022e1c8ad	17	application_approved	250805 Novalic Damir offer IFZA (International Free Zone Authority) Approved	good to go	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 09:22:25.092961	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
65c4a1d8-5bb7-4bf6-8052-87fc7f0a6e92	32	application_approved	250801 Novalic Damir offer golden visa property Approved	go t o go	8e7ca7dd-b9ef-45fe-a580-5b6caa2f7df6	t	2025-08-01 12:02:49.519137	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
93c0cefc-aa47-4796-8275-44c4be5e40fb	2	review_requested	250805 Client offer golden visa undefined	qqq111	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:47:49.479767	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
943a99d2-5c85-4a5d-a65c-775eee21684e	2	review_requested	250805 Client offer golden visa undefined	test cost overview	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:24:12.230457	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
edb963a9-32e1-4f9d-8b5a-c2188e37df27	2	review_requested	250805 Client offer golden visa undefined	aaaaa	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 08:51:06.59824	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
e7d6584e-26a0-49bb-a33c-a308590a9127	2	review_requested	250805 Novalic Damir IFZA International Free Zone Authority setup offer	aaaa 1	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 09:28:44.577119	{"submitter_name": "Damir Novalic", "submitter_employee_code": "70 DN"}
6c4eadda-978d-4134-aa92-1e8afb58a2d2	17	application_rejected	250805 Novalic Damir IFZA International Free Zone Authority setup offer Rejected	nope more detials	1b227812-350b-43cb-a94c-7a9d1c105cd1	t	2025-08-05 09:30:32.81892	{"reviewer_name": "Uwe Hohmann", "reviewer_employee_code": "09 UH"}
\.


--
-- TOC entry 3528 (class 0 OID 16421)
-- Dependencies: 218
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.permissions (id, name, description, resource, action, created_at) FROM stdin;
1	cost_overview_read	View cost overview calculations	cost_overview	read	2025-07-22 16:44:56.8482
2	cost_overview_write	Create and edit cost overviews	cost_overview	write	2025-07-22 16:44:56.8482
3	cost_overview_export	Export cost overview PDFs	cost_overview	export	2025-07-22 16:44:56.8482
4	company_services_read	View company services	company_services	read	2025-07-22 16:44:56.8482
5	company_services_write	Create and edit company services	company_services	write	2025-07-22 16:44:56.8482
6	company_services_export	Export company services PDFs	company_services	export	2025-07-22 16:44:56.8482
7	golden_visa_read	View golden visa applications	golden_visa	read	2025-07-22 16:44:56.8482
8	golden_visa_write	Create and edit golden visa applications	golden_visa	write	2025-07-22 16:44:56.8482
9	golden_visa_export	Export golden visa PDFs	golden_visa	export	2025-07-22 16:44:56.8482
10	taxation_read	View taxation documents	taxation	read	2025-07-22 16:44:56.8482
11	taxation_write	Create and edit taxation documents	taxation	write	2025-07-22 16:44:56.8482
12	taxation_export	Export taxation PDFs	taxation	export	2025-07-22 16:44:56.8482
13	user_management	Manage user accounts	users	admin	2025-07-22 16:44:56.8482
14	system_admin	System administration access	system	admin	2025-07-22 16:44:56.8482
15	audit_logs	View audit logs	audit	read	2025-07-22 16:44:56.8482
16	review_applications	Review submitted applications	applications	review	2025-07-28 15:08:35.310765
17	view_notifications	View in-app notifications	notifications	read	2025-07-28 15:08:35.310765
18	manage_notifications	Manage notification settings	notifications	write	2025-07-28 15:08:35.310765
\.


--
-- TOC entry 3533 (class 0 OID 16498)
-- Dependencies: 223
-- Data for Name: security_alert_acknowledgments; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.security_alert_acknowledgments (alert_id, acknowledged_by, acknowledged_at) FROM stdin;
17	1	2025-07-23 06:42:16.924252
7	1	2025-07-23 06:42:19.87023
3	1	2025-07-23 06:42:23.921227
\.


--
-- TOC entry 3526 (class 0 OID 16406)
-- Dependencies: 216
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.sessions (id, user_id, expires_at, ip_address, user_agent, created_at, last_activity) FROM stdin;
8c328fae-51a4-42fd-8b74-90e31bc3da10	17	2025-08-05 17:21:32.858	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 05:21:32.857308	2025-08-05 05:21:32.857308
240a9834-3932-42a7-97b6-c7fe3c51312f	2	2025-08-05 20:24:50.451	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 08:24:50.44824	2025-08-05 08:24:50.44824
8f766b87-2e17-44cd-8314-d6a1ce27fe91	17	2025-08-05 17:42:59.362	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-08-05 09:42:59.362627	2025-08-05 09:42:59.362627
\.


--
-- TOC entry 3532 (class 0 OID 16468)
-- Dependencies: 222
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.system_config (key, value, description, updated_by, updated_at) FROM stdin;
password_policy	{"min_length": 8, "require_numbers": true, "require_symbols": true, "require_lowercase": true, "require_uppercase": true}	Password complexity requirements	\N	2025-07-22 16:44:56.848907
session_timeout	28800	Session timeout in seconds (8 hours)	\N	2025-07-22 16:44:56.848907
max_login_attempts	5	Maximum failed login attempts before account lockout	\N	2025-07-22 16:44:56.848907
lockout_duration	1800	Account lockout duration in seconds (30 minutes)	\N	2025-07-22 16:44:56.848907
company_name	"TME Services"	Company name for branding	\N	2025-07-22 16:44:56.848907
admin_email	"uwe@TME-Services.com"	System administrator email	\N	2025-07-22 16:44:56.848907
\.


--
-- TOC entry 3529 (class 0 OID 16432)
-- Dependencies: 219
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.user_permissions (user_id, permission_id, granted_by, granted_at) FROM stdin;
\.


--
-- TOC entry 3525 (class 0 OID 16386)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tme_user
--

COPY public.users (id, employee_code, email, full_name, department, designation, hashed_password, role, status, must_change_password, last_password_change, failed_login_attempts, locked_until, created_at, updated_at, last_login) FROM stdin;
12	48 AB	ashly@TME-Services.com	Ashly Biju	Accounting	Accountant	$2b$12$wBpskegBqVRWv8Poo7waZ.9FIYVLd5eA5tvpR8Sv8hbk/oMl4EsOS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
14	53 JT	jovel@TME-Services.com	Jovel Monton Tiro	Client Support	Administrative Supervisor	$2b$12$awVCySwpo7BhXUOdECa3m.Kgx5/MxYM/haqsNPbzF.3B5gyJ1VZ4K	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
16	65 WM	wilma@TME-Services.com	Wilma Menezes	Client Support	Client Support Coordinator	$2b$12$XiI0.oc75HEOFRlvnO0sseWqbZRFo/nhHi7vGEC/ZSUZSZdUyp8SW	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
18	75 WS	wafa@TME-Services.com	Wafa Sulthana Masood	Client Support	Client Support Coordinator	$2b$12$FfmPFckdcvqBfJaOozRQZet6zaW02C/7kwXktcLkR.xwk9.HgRlhy	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
19	76 RA	rowelyn@TME-Services.com	Rowelyn Allibang Jocson	Client Support	Marketing Specialist	$2b$12$Rr/9JO6JgZIQkZQ9hzlRy.ahDbvwmX46RVsuF.tgXr33daaTGi3Em	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
20	79 ST	surya@TME-Services.com	Surya Padmakumari Thulaseedharan	Client Support	Client Support Coordinator	$2b$12$ArlRYsHbopVGsY/rls9qdemoCdPQxgFJGiiTLgh9iRNRQNgrEpmMK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
21	80 RoJ	roja@TME-Services.com	Roja James	Tax & Compliance	Accountant	$2b$12$Vv84K9OZbhRs1l2a13cJEeUN8gxXlb.JpM9bHlSHpEidASSiPo8K2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
22	82 AC	alyssa@TME-Services.com	Alyssa Marie Jimenez Castillo	Client Support	Client Support Coordinator	$2b$12$MyAdnbDBMQUlUTJzjNwULut5k4pqTPnwRJgvltLmZfq5q76tideW2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
23	83 TM	tanya@TME-Services.com	Tanya Maria Miranda	Accounting	Accountant	$2b$12$yf3ssBi7.CdZ6rc2dXmeD.nUT1H4Ay7Jm5QlpcQP5rh.pk/Jx68Y.	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
24	86 MA	muhammed@TME-Services.com	Muhammed Anshad Chandveettil	Tax & Compliance	Accountant	$2b$12$/L6DbpuWBaR7.cgN6m8.qe/tVxQlnSJcDIBgeER3MwcX6emg1NQV.	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
25	87 VR	via@TME-Services.com	Via Andrea Rosales	Client Support	Receptionist	$2b$12$sKtOL3dmbUAe0AKp5aPOxuqsMtnySJBteCAZ6GyxnfZEI32T1M2uq	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
27	89 RR	renji@TME-Services.com	Renji Reghunadh	Client Support	Administration Manager	$2b$12$WSGVqnm807A8/wmBGNkVwu5jf/rPxW7.qQkZG/jNP6IPJjCtxIh/y	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
28	90 MD	alicia@TME-Services.com	Alicia Myles Elamparo Dela Cruz	Accounting	Assistant Accountant	$2b$12$K9Iuwvp7itX4VQmZT5WFpu9vb17.ZwUVT2J283itp.RDNLKBDlCt2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
29	91 PG	priya@TME-Services.com	Priya Ganapathy Kariappa	Client Support	Client Support Coordinator	$2b$12$W6WhAIiIfS/.wkWGnv41M.x3/uyG7wJuv2.geWskDGNQ94mjczAY6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
30	92 CM	chirath@TME-Services.com	Chirath Deshitha Mayakaduwa	Tax & Compliance	Accountant	$2b$12$GsPJ38WpwSDa/buXz85BX.0huZ8Dwp0FF.t/SD.SRW6..WIqjXBCK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
31	95 Sis	saquib@TME-Services.com	Saquib Siraj	Accounting	Accountant	$2b$12$6ubCs9./.kGnGh4aLj3j4u2gKJR7Q5Fgncm5s/GKek1aNRtPrkKri	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
33	98 NP	nidhi@TME-Services.com	Nidhi Pandey	Accounting	Accountant	$2b$12$9zoG6u7/IHOEVhzIycAfLuJF6SdSt8Cb.3uxcRytgLds9QtDyeleO	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
34	99 AtS	atheesha@TME-Services.com	Atheesha Shetty	Accounting	Accountant	$2b$12$czaGoPDdbfAPs2kbWG8naesXRv43OqetN8.ZVJ59ugGktp.wIxXm6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
35	100 MB	mehran@TME-Services.com	Mehran Masood Barde	Accounting	Accountant	$2b$12$3Ewzg5urFf06jb8XTUZAguLRDBOXxfI9XzYrJSlDadKSZHZ0b6QMK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
26	88 AjA	aiswarya@TME-Services.com	Aiswarya Ajaykumar	Client Support	Client Support Coordinator	$2b$12$0/SMlKIWH5U4MLyKklxmsuwevACddCFocZUw86zeo04pK5DLrSScS	employee	active	t	2025-07-23 05:24:14.193621	0	\N	2025-07-22 16:44:56.86661	2025-07-23 05:24:14.193621	\N
7	25 KM	pro@TME-Services.com	Kumar & Ulesh	Client Support	Public Relation Officer (PRO)	$2b$12$qX9HtLpPC7kU6f4stkygUeKIjXvqpF0Fh..x94AaUz4nTKUIB2YqK	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:35:59.346145	\N
3	MGT001	manager1@TME-Services.com	Manager One	Management	Operations Manager	$2b$12$fFSed.nXGgGmFeYcQZDyAuYgTQhtlMRECXBEOwavBXwbv.6q/Sjmm	manager	active	f	2025-07-23 08:23:36.74016	0	\N	2025-07-22 16:44:56.86661	2025-07-29 06:23:16.061179	2025-07-23 08:28:17.393144
13	50 PA	praveen@TME-Services.com	Praveen Anton	IT	System Administrator	$2b$12$KttUW.oKyYXTIg7DM/UAmuYivEWzq7qnMkhrCs838Z02EcYKz.Q/a	admin	active	f	2025-07-23 08:23:27.410984	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:23:50.799557	\N
5	IT001	itlead@TME-Services.com	IT Lead	IT	IT Team Lead	$2b$12$fFSed.nXGgGmFeYcQZDyAuYgTQhtlMRECXBEOwavBXwbv.6q/Sjmm	manager	active	f	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-29 06:23:16.064782	\N
6	23 TA	tabassum@TME-Services.com	Tabassum Arif	Accounting	Client Support Coordinator	$2b$12$OnHAmXzi3A2v8vyQk7oShu3FhHWZtAIcCSt2V7dXpQ7DqSVdjpLqa	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:00.115184	\N
8	33 MK	malavika@TME-Services.com	Malavika Kolera	Tax & Compliance	Director - Tax & Compliance	$2b$12$AHoq8AOHDgHpcBPABL638.gPD0JCRDABhhZwYRcFdx/Wcb65DD.Y.	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:15.233689	\N
9	38 TZ	tariq@TME-Services.com	Tariq Zarif	Accounting	Accounting Manager	$2b$12$ziEoWTTEBTDi9AcMXxI5weL.uJnk9c4waXNEmLD9CY9rGtr5SlXmK	manager	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:29.343348	\N
10	40 AS	akash@TME-Services.com	Akash Shetty	Accounting	Accountant	$2b$12$BJYd2Kj3k20ICBRsibg46OIfV/iUoI/yy.wCEvuJSHE6jnvYRQtNC	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:21:40.072197	\N
11	42 RJ	reshma@TME-Services.com	Reshma Joseph	Tax & Compliance	Manager - VAT	$2b$12$gWpikDxiWiUCf4SqFWluvO2SHWXOzEyIg0cBMuGgR1uSTqn/oN2LS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:22:03.475263	\N
15	58 YF	yashika@TME-Services.com	Yashika Fernandes	Tax & Compliance	Manager - Compliance	$2b$12$grhFNo1XhOY.opXk7sMm2u0blsmy4TPfGE2S77cjjmkyy.wpC0yI6	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-23 08:22:53.189314	\N
36	102 OO	onur@TME-Services.com	Onur Ozturk	Company Setup	Business Development Assistant	$2b$12$MGeVbEdtwYOjomVyUBqZZO5Rlw9ZnK5lUI10hOJhnqX8yyLcqirgG	employee	active	t	\N	2	\N	2025-07-22 16:44:56.86661	2025-07-28 13:48:14.450656	\N
4	MGT002	manager2@TME-Services.com	Manager Two	Management	Finance Manager	$2b$12$fFSed.nXGgGmFeYcQZDyAuYgTQhtlMRECXBEOwavBXwbv.6q/Sjmm	manager	active	f	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-29 06:23:16.062842	\N
2	09 UH	uwe@TME-Services.com	Uwe Hohmann	Management	CEO	$2b$12$yEMLkn6roK4ZGT0boLbkeOS7cIey4cKwsk2kaJQSdU0u5/aPGvtTS	admin	active	f	2025-07-29 06:43:10.448614	0	\N	2025-07-22 16:44:56.86661	2025-08-05 08:24:50.439143	2025-08-05 08:24:50.439143
32	96 TR	tina@TME-Services.com	Tina Reimann	Company Setup	Assistant - Business Development	$2b$12$APzz85vN/CSHWbK5viSInOusl3z/STqm8fsFtA8nhd.TcjAVhSE/S	employee	active	f	2025-07-23 08:24:56.749222	0	\N	2025-07-22 16:44:56.86661	2025-08-01 11:55:14.462547	2025-08-01 11:55:14.462547
38	105 MM	milani@TME-Services.com	Milani Listin Morris	Client Support	Front Desk Support	$2b$12$xWNePVOt0f3K6Zn9dbPQnuvnPoBTsdfsKBGjUmbj/AZG5O8NZf9gW	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
39	106 CV	charltzon@TME-Services.com	Charltzon Varghese	Accounting	Accountant	$2b$12$fPkdhqX2QxWHBgkCTWhNZOxfTQ.298nMhC1f.U.fXERpf88eQdrp2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
40	108 MR	mohamed@TME-Services.com	Mohamed Rashid Basheer	Accounting	Accountant	$2b$12$At5piP59Q26auBZjUS6mqOZSR5HjXJvxTc7E3rpG/xWFcjkTXTt0C	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
41	109 PS	princyss@TME-Services.com	Princyss Sampaga	Client Support	Administration Officer	$2b$12$TjYj8oODSqgBfjJoNBR0OugFiZrovCQqdyV7eD/NzjtMOT7cCBgKS	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
42	110 CD	carol@TME-Services.com	Carol Jenifa Dalmeida	Accounting	Accountant	$2b$12$Y88ngJPyof0nQ1zyIWxisO9XnYuQ/JcgLzCarZIPoHKcA0Ib10Gn2	employee	active	t	\N	0	\N	2025-07-22 16:44:56.86661	2025-07-22 16:44:56.86661	\N
1	TME001	testuser@TME-Services.com	Test User	IT	Software Developer	$2b$12$fFSed.nXGgGmFeYcQZDyAuYgTQhtlMRECXBEOwavBXwbv.6q/Sjmm	employee	active	f	2025-07-22 17:05:35.106219	0	\N	2025-07-22 16:44:56.86661	2025-07-29 06:23:16.039163	2025-07-29 04:46:04.925777
37	103 BD	brayan@TME-Services.com	Brayan Dsouza	IT	Information Technology Consultant	$2b$12$S73PMwjnSzknWJHYQRvavOCsKDAfRPfBjFzINAgcGsxgICfNl/Bpu	employee	active	f	2025-07-23 08:24:40.956203	0	\N	2025-07-22 16:44:56.86661	2025-07-24 11:53:24.140436	2025-07-24 11:53:24.140436
17	70 DN	damir@TME-Services.com	Damir Novalic	Marketing 	Manager - Digital Marketing	$2b$12$xDF1tMmOJncH6fFf/jJD3uF2NlcWEKtbR3AQCLPT7d5MtS4cfkmnW	admin	active	f	2025-07-23 07:06:49.398946	0	\N	2025-07-22 16:44:56.86661	2025-08-05 09:42:59.356396	2025-08-05 09:42:59.356396
\.


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 220
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 676, true);


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 217
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 18, true);


--
-- TOC entry 3547 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tme_user
--

SELECT pg_catalog.setval('public.users_id_seq', 42, true);


--
-- TOC entry 3355 (class 2606 OID 16524)
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- TOC entry 3347 (class 2606 OID 16462)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3367 (class 2606 OID 16545)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 3341 (class 2606 OID 16431)
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- TOC entry 3343 (class 2606 OID 16429)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3353 (class 2606 OID 16503)
-- Name: security_alert_acknowledgments security_alert_acknowledgments_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.security_alert_acknowledgments
    ADD CONSTRAINT security_alert_acknowledgments_pkey PRIMARY KEY (alert_id);


--
-- TOC entry 3339 (class 2606 OID 16414)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3351 (class 2606 OID 16475)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- TOC entry 3345 (class 2606 OID 16437)
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (user_id, permission_id);


--
-- TOC entry 3331 (class 2606 OID 16405)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3333 (class 2606 OID 16403)
-- Name: users users_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_code_key UNIQUE (employee_code);


--
-- TOC entry 3335 (class 2606 OID 16401)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3356 (class 1259 OID 16560)
-- Name: idx_applications_created_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_applications_created_at ON public.applications USING btree (created_at);


--
-- TOC entry 3357 (class 1259 OID 16557)
-- Name: idx_applications_reviewer; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_applications_reviewer ON public.applications USING btree (reviewer_id);


--
-- TOC entry 3358 (class 1259 OID 16558)
-- Name: idx_applications_status; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_applications_status ON public.applications USING btree (status);


--
-- TOC entry 3359 (class 1259 OID 16556)
-- Name: idx_applications_submitted_by; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_applications_submitted_by ON public.applications USING btree (submitted_by_id);


--
-- TOC entry 3360 (class 1259 OID 16559)
-- Name: idx_applications_type; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_applications_type ON public.applications USING btree (type);


--
-- TOC entry 3348 (class 1259 OID 16487)
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- TOC entry 3349 (class 1259 OID 16486)
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- TOC entry 3361 (class 1259 OID 16564)
-- Name: idx_notifications_application_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_notifications_application_id ON public.notifications USING btree (application_id);


--
-- TOC entry 3362 (class 1259 OID 16563)
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at);


--
-- TOC entry 3363 (class 1259 OID 16562)
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- TOC entry 3364 (class 1259 OID 24702)
-- Name: idx_notifications_metadata; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_notifications_metadata ON public.notifications USING gin (metadata);


--
-- TOC entry 3365 (class 1259 OID 16561)
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- TOC entry 3336 (class 1259 OID 16485)
-- Name: idx_sessions_expires_at; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_sessions_expires_at ON public.sessions USING btree (expires_at);


--
-- TOC entry 3337 (class 1259 OID 16484)
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- TOC entry 3327 (class 1259 OID 16482)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3328 (class 1259 OID 16481)
-- Name: idx_users_employee_code; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_employee_code ON public.users USING btree (employee_code);


--
-- TOC entry 3329 (class 1259 OID 16483)
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: tme_user
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- TOC entry 3380 (class 2620 OID 16491)
-- Name: sessions clean_sessions_trigger; Type: TRIGGER; Schema: public; Owner: tme_user
--

CREATE TRIGGER clean_sessions_trigger AFTER INSERT ON public.sessions FOR EACH STATEMENT EXECUTE FUNCTION public.clean_expired_sessions();


--
-- TOC entry 3381 (class 2620 OID 16565)
-- Name: applications update_applications_updated_at; Type: TRIGGER; Schema: public; Owner: tme_user
--

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON public.applications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3379 (class 2620 OID 16489)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: tme_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3375 (class 2606 OID 16530)
-- Name: applications applications_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3376 (class 2606 OID 16525)
-- Name: applications applications_submitted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_submitted_by_id_fkey FOREIGN KEY (submitted_by_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3372 (class 2606 OID 16463)
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3377 (class 2606 OID 16551)
-- Name: notifications notifications_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- TOC entry 3378 (class 2606 OID 16546)
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3374 (class 2606 OID 16504)
-- Name: security_alert_acknowledgments security_alert_acknowledgments_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.security_alert_acknowledgments
    ADD CONSTRAINT security_alert_acknowledgments_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- TOC entry 3368 (class 2606 OID 16415)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3373 (class 2606 OID 16476)
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 3369 (class 2606 OID 16448)
-- Name: user_permissions user_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- TOC entry 3370 (class 2606 OID 16443)
-- Name: user_permissions user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3371 (class 2606 OID 16438)
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tme_user
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-08-05 09:45:16 UTC

--
-- PostgreSQL database dump complete
--

